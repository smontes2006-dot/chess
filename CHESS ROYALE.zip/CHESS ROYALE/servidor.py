from red import Red

red = Red()

red.iniciar_servidor()

while True:

    if red.mensajes:
        print(red.mensajes.pop(0))

    mensaje = input("Enviar: ")

    red.enviar(mensaje)
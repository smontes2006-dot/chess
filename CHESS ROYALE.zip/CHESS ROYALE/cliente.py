from red import Red

red = Red()

ip = input("IP del servidor: ")

red.conectar(ip)

while True:

    if red.mensajes:
        print(red.mensajes.pop(0))

    mensaje = input("Enviar: ")

    red.enviar(mensaje)
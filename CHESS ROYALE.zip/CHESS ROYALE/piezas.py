"""
CLASH CHESS - Módulo de Piezas
"""

import pygame
from utils import (TAMANO_CASILLA, COLOR_PIEZA_J1, COLOR_PIEZA_J2,
                   COLOR_PIEZA_BORDE, fila_col_a_pixel,
                   JUGADOR_1, JUGADOR_2)

class Pieza:
    """
    Clase base de la que heredan todas las piezas del juego.
    """

    def __init__(self, fila, col, jugador, nombre, simbolo):
        self.fila    = fila
        self.col     = col
        self.jugador = jugador
        self.nombre  = nombre
        self.simbolo = simbolo
        self.viva    = True

    def obtener_movimientos(self, tablero):
        """
        Calcula y retorna los movimientos válidos de esta pieza.
        """
        raise NotImplementedError(
            f"{self.nombre} debe implementar obtener_movimientos()"
        )
    #  Dibujo de la pieza en pantalla

    def dibujar(self, superficie, seleccionada=False):
        """
        Dibuja la pieza como un círculo con su símbolo encima.
        """
        # Calcular posición en píxeles (centro de la casilla)
        x, y = fila_col_a_pixel(self.fila, self.col)
        cx = x + TAMANO_CASILLA // 2
        cy = y + TAMANO_CASILLA // 2
        radio = TAMANO_CASILLA // 2 - 6

        # Color según el jugador dueño de la pieza
        color_fill  = COLOR_PIEZA_J1 if self.jugador == JUGADOR_1 else COLOR_PIEZA_J2
        color_borde = COLOR_PIEZA_BORDE

        # Sombra sutil para dar profundidad
        pygame.draw.circle(superficie, (0, 0, 0, 80),
                           (cx + 2, cy + 3), radio)

        # Círculo principal de la pieza
        pygame.draw.circle(superficie, color_fill, (cx, cy), radio)

        # Borde de la pieza
        pygame.draw.circle(superficie, color_borde, (cx, cy), radio, 2)

        # Borde dorado si está seleccionada
        if seleccionada:
            pygame.draw.circle(superficie, (255, 220, 0),
                               (cx, cy), radio, 3)

        # Símbolo / emoji de la pieza
        fuente = pygame.font.SysFont("Segoe UI Emoji", 22)
        render_sim = fuente.render(self.simbolo, True, (255, 255, 255))
        sx = cx - render_sim.get_width()  // 2
        sy = cy - render_sim.get_height() // 2
        superficie.blit(render_sim, (sx, sy))
    # Métodos auxiliares para validar movimientos

    def _es_valida(self, fila, col):
        """
        Verifica si una casilla está dentro del tablero.
        """
        return 0 <= fila < 8 and 0 <= col < 8

    def _casilla_libre_o_enemiga(self, fila, col, tablero):
        """
        Retorna True si la casilla está vacía o tiene
        una pieza enemiga (es decir, se puede mover ahí).
        """
        pieza = tablero.obtener_pieza(fila, col)
        return pieza is None or pieza.jugador != self.jugador

    def _es_enemigo(self, fila, col, tablero):
        """
        Retorna True si hay una pieza enemiga en esa casilla.
        """
        pieza = tablero.obtener_pieza(fila, col)
        return pieza is not None and pieza.jugador != self.jugador

    def __repr__(self):
        return f"{self.nombre}(J{self.jugador}, fila={self.fila}, col={self.col})"

#  PIEZA: Rey

class Rey(Pieza):

    def __init__(self, fila, col, jugador):
        # La corona ♛ o 👑 identifica al Rey visualmente
        super().__init__(fila, col, jugador, "Rey", "👑")

    def obtener_movimientos(self, tablero):
        movimientos = []

        # Las 8 direcciones: (delta_fila, delta_col)
        direcciones = [
            (-1, -1), (-1, 0), (-1, 1),   # arriba-izq, arriba, arriba-der
            ( 0, -1),          ( 0, 1),    # izquierda,           derecha
            ( 1, -1), ( 1, 0), ( 1, 1),   # abajo-izq, abajo, abajo-der
        ]

        for df, dc in direcciones:
            nf = self.fila + df
            nc = self.col  + dc
            if self._es_valida(nf, nc) and self._casilla_libre_o_enemiga(nf, nc, tablero):
                movimientos.append((nf, nc))

        return movimientos

class Gigante(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Gigante", "🗿")

    def obtener_movimientos(self, tablero):
        movimientos = []

        # Dirección "adelante" depende del jugador
        # J1 sube (fila decrece), J2 baja (fila crece)
        adelante = -1 if self.jugador == JUGADOR_1 else 1

        # Definir las 3 direcciones del Gigante:
        # adelante, izquierda, derecha
        direcciones_lineales = [
            (adelante,  0),   # Avanzar al frente
            (0,        -1),   # Moverse a la izquierda
            (0,         1),   # Moverse a la derecha
        ]

        for df, dc in direcciones_lineales:
            nf, nc = self.fila + df, self.col + dc

            # Recorrer en esa dirección hasta el borde
            while self._es_valida(nf, nc):
                pieza_en_casilla = tablero.obtener_pieza(nf, nc)

                if pieza_en_casilla is None:
                    # Casilla vacía: puede moverse aquí
                    movimientos.append((nf, nc))
                elif pieza_en_casilla.jugador != self.jugador:
                    # Enemigo: puede capturarlo, pero no pasar
                    movimientos.append((nf, nc))
                    break
                else:
                    # Pieza propia: bloquea el camino
                    break

                nf += df
                nc += dc

        return movimientos

class Princesa(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Princesa", "🏹")

    def obtener_movimientos(self, tablero):
        movimientos = []
        adelante = -1 if self.jugador == JUGADOR_1 else 1

        # --- MOVIMIENTO: 1 casilla en cualquier dirección ---
        for df in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if df == 0 and dc == 0:
                    continue  # No contar la casilla actual
                nf = self.fila + df
                nc = self.col  + dc
                if self._es_valida(nf, nc) and self._casilla_libre_o_enemiga(nf, nc, tablero):
                    # Solo moverse a casillas vacías (no atacar cuerpo a cuerpo)
                    pieza = tablero.obtener_pieza(nf, nc)
                    if pieza is None:
                        movimientos.append((nf, nc))

        # --- ATAQUE A DISTANCIA: hasta 3 casillas al frente ---
        for distancia in range(1, 4):
            nf = self.fila + adelante * distancia
            nc = self.col   # Misma columna (línea recta)

            if not self._es_valida(nf, nc):
                break

            pieza = tablero.obtener_pieza(nf, nc)

            if pieza is None:
                # Casilla vacía: el disparo puede seguir pasando
                continue
            elif pieza.jugador != self.jugador:
                # Enemigo dentro del rango: puede atacarlo
                movimientos.append((nf, nc))
                break  # El disparo se detiene al impactar
            else:
                # Aliado bloquea la línea de disparo
                break

        return movimientos

class Mago(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Mago", "🧙")
        
    def obtener_movimientos(self, tablero):
        movimientos = []
        adelante = -1 if self.jugador == JUGADOR_1 else 1

        # Diagonales
        direcciones = [
            (-1, -1),
            (-1, 1),
            (1, -1),
            (1, 1),

            # Adelante
            (adelante, 0)
        ]

        for df, dc in direcciones:

            for paso in range(1, 3):

                nf = self.fila + df * paso
                nc = self.col + dc * paso

                if not self._es_valida(nf, nc):
                    break

                pieza = tablero.obtener_pieza(nf, nc)

                if pieza is None:
                    movimientos.append((nf, nc))

                elif pieza.jugador != self.jugador:
                    movimientos.append((nf, nc))
                    break

                else:
                    break

        return movimientos

class Duende(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Duende", "👺")

    def obtener_movimientos(self, tablero):
        movimientos = []

        adelante = -1 if self.jugador == JUGADOR_1 else 1

        direcciones = [
            (adelante, 0),   # Frente
            (0, -1),         # Izquierda
            (0, 1),          # Derecha
        ]

        for df, dc in direcciones:
            nf = self.fila + df
            nc = self.col + dc

            if not self._es_valida(nf, nc):
                continue

            pieza = tablero.obtener_pieza(nf, nc)

            # Casilla vacía o enemigo
            if pieza is None or pieza.jugador != self.jugador:
                movimientos.append((nf, nc))

        return movimientos
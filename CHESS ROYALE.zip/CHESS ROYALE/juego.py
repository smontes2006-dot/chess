"""
CLASH CHESS - Módulo del Juego
"""

import pygame
from tablero import Tablero
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA, TAMANO_CASILLA,
    MARGEN_IZQ, MARGEN_SUP,
    COLOR_FONDO_UI, COLOR_TEXTO, COLOR_TITULO,
    COLOR_BANNER_J1, COLOR_BANNER_J2, COLOR_BORDE,
    COLOR_BOTON, COLOR_BOTON_HOVER,
    JUGADOR_1, JUGADOR_2, NOMBRE_J1, NOMBRE_J2,
    pixel_a_fila_col, dibujar_boton, obtener_fuentes
)


class Juego:
    """
    Clase principal de la partida.
    """

    def __init__(self, ventana, red=None, mi_jugador=None):
        self.ventana    = ventana
        self.fuentes    = obtener_fuentes()
        self.red        = red
        self.mi_jugador = mi_jugador

        self._reiniciar()

    def _reiniciar(self):
        """
        Reinicia todos los datos de la partida.
        Se llama al iniciar o al jugar de nuevo.
        """
        self.tablero       = Tablero()
        self.turno_actual  = JUGADOR_1    # J1 siempre empieza
        self.pieza_selec   = None         # Ninguna pieza seleccionada
        self.movs_validos  = []           # Sin movimientos resaltados
        self.ganador       = None         # Aún sin ganador
        self.mensaje_turno = self._nombre_turno()

    #  BUCLE PRINCIPAL DE LA PANTALLA DE JUEGO

    def ejecutar(self):
        """
        Bucle de la pantalla de juego. 
        """
        reloj = pygame.time.Clock()

        while True:
            # --- Gestión de eventos ---
            for evento in pygame.event.get():

                if evento.type == pygame.QUIT:
                    return "salir"

                if evento.type == pygame.KEYDOWN:
                    # ESC regresa al menú
                    if evento.key == pygame.K_ESCAPE:
                        return "menu"

                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if evento.button == 1:   # Click izquierdo
                        resultado = self._manejar_click(evento.pos)
                        if resultado:
                            return resultado

            if self.red is not None:
                self._procesar_movimiento_remoto()

            # --- Dibujo ---
            self._dibujar()
            pygame.display.flip()
            reloj.tick(60)

    #  MANEJO DE CLICKS DEL MOUSE

    def _manejar_click(self, pos):
        """
        Procesa un click del mouse según el estado actual.
        """
        # Si hay un ganador, manejar los botones de victoria
        if self.ganador:
            return self._click_pantalla_victoria(pos)

        if self.red is not None and self.turno_actual != self.mi_jugador:
            return None   # No es tu turno: ignorar click

        # Convertir pixel → casilla del tablero
        casilla = pixel_a_fila_col(pos[0], pos[1])

        if casilla is None:
            # Click fuera del tablero: deseleccionar
            self._deseleccionar()
            return None

        fila, col = casilla

        if self.pieza_selec is None:
            # No hay pieza seleccionada: intentar seleccionar una
            self._intentar_seleccionar(fila, col)
        else:
            # Ya hay pieza seleccionada: intentar mover
            if (fila, col) in self.movs_validos:
                self._ejecutar_movimiento(fila, col)
            elif self._es_pieza_propia(fila, col):
                # Click en otra pieza propia: cambiar selección
                self._intentar_seleccionar(fila, col)
            else:
                # Click inválido: deseleccionar
                self._deseleccionar()

        return None

    def _intentar_seleccionar(self, fila, col):
        """
        Intenta seleccionar la pieza en (fila, col).
        Solo se puede seleccionar una pieza del jugador activo.
        """
        pieza = self.tablero.obtener_pieza(fila, col)

        if pieza and pieza.jugador == self.turno_actual:
            self.pieza_selec  = pieza
            self.movs_validos = pieza.obtener_movimientos(self.tablero)
        else:
            self._deseleccionar()

    def _deseleccionar(self):
        """Limpia la selección y los movimientos resaltados."""
        self.pieza_selec  = None
        self.movs_validos = []

    def _ejecutar_movimiento(self, nueva_fila, nueva_col):
        """
        Mueve la pieza seleccionada a la casilla destino.
        """
        origen  = (self.pieza_selec.fila, self.pieza_selec.col)
        destino = (nueva_fila, nueva_col)

        if self.red is not None:
            self.red.enviar_movimiento(origen, destino)

        # Ejecutar movimiento (puede capturar)
        self.tablero.mover_pieza(self.pieza_selec, nueva_fila, nueva_col)

        # Verificar condición de victoria
        self.ganador = self.tablero.verificar_victoria()

        # Limpiar selección
        self._deseleccionar()

        # Cambiar de turno si la partida continúa
        if not self.ganador:
            self._cambiar_turno()


    def _procesar_movimiento_remoto(self):
        """
        Revisa la cola de mensajes de red. Si llegó un movimiento
        del oponente (cuando es su turno), lo aplica al tablero.
        """
        # Solo procesar cuando es el turno del oponente
        if self.turno_actual == self.mi_jugador:
            return

        if not self.red.mensajes:
            return

        datos = self.red.mensajes.pop(0)

        # Validar que el mensaje tenga la forma correcta
        if "origen" not in datos or "destino" not in datos:
            return

        fila_o, col_o = datos["origen"]
        fila_d, col_d = datos["destino"]

        pieza = self.tablero.obtener_pieza(fila_o, col_o)

        if pieza is None:
            return   # Movimiento inválido: ignorar

        # Aplicar el movimiento remoto
        self.tablero.mover_pieza(pieza, fila_d, col_d)

        # Verificar victoria
        self.ganador = self.tablero.verificar_victoria()

        # Cambiar turno al jugador local
        if not self.ganador:
            self._cambiar_turno()

    #  HELPERS DE TURNO

    def _cambiar_turno(self):
        """Alterna el turno entre jugador 1 y jugador 2."""
        self.turno_actual = (JUGADOR_2 if self.turno_actual == JUGADOR_1
                             else JUGADOR_1)
        self.mensaje_turno = self._nombre_turno()

    def _es_pieza_propia(self, fila, col):
        """
        Verifica si en una casilla hay una pieza del jugador activo.
        """
        pieza = self.tablero.obtener_pieza(fila, col)
        return pieza is not None and pieza.jugador == self.turno_actual

    def _nombre_turno(self):
        """Retorna el nombre del jugador cuyo turno es."""
        return NOMBRE_J1 if self.turno_actual == JUGADOR_1 else NOMBRE_J2

    #  DIBUJO GENERAL

    def _dibujar(self):
        """Dibuja todos los elementos visuales del frame actual."""
        self.ventana.fill((20, 16, 30))
        self.tablero.dibujar(self.ventana, self.pieza_selec,
                             self.movs_validos)
        self._dibujar_panel_info()
        if self.ganador:
            self._dibujar_pantalla_victoria()

    def _dibujar_panel_info(self):
        """
        Dibuja el panel informativo a la derecha del tablero.
        CAMBIO: muestra "Tu turno" / "Turno del oponente" en online.
        """
        px = MARGEN_IZQ + 8 * TAMANO_CASILLA + 15
        py = MARGEN_SUP
        ancho_panel = ANCHO_VENTANA - px - 10
        alto_panel  = 8 * TAMANO_CASILLA

        panel_rect = pygame.Rect(px, py, ancho_panel, alto_panel)
        pygame.draw.rect(self.ventana, COLOR_FONDO_UI,
                         panel_rect, border_radius=10)
        pygame.draw.rect(self.ventana, COLOR_BORDE,
                         panel_rect, 2, border_radius=10)

        y = py + 10

        f_grande  = self.fuentes["grande"]
        f_normal  = self.fuentes["normal"]
        f_pequeña = self.fuentes["pequeña"]

        txt = f_grande.render("⚔ Turno", True, COLOR_TITULO)
        self.ventana.blit(txt, (px + 10, y))
        y += 38

        color_banner = (COLOR_BANNER_J1 if self.turno_actual == JUGADOR_1
                        else COLOR_BANNER_J2)
        banner_rect = pygame.Rect(px + 5, y, ancho_panel - 10, 36)
        pygame.draw.rect(self.ventana, color_banner,
                         banner_rect, border_radius=6)

        # ── NUEVO: etiqueta especial en modo online ───────────
        if self.red is not None:
            if self.turno_actual == self.mi_jugador:
                nombre = "⬅ Tu turno"
            else:
                nombre = "⏳ Oponente..."
        else:
            nombre = self._nombre_turno()

        txt = f_normal.render(nombre, True, COLOR_TEXTO)
        tx = banner_rect.x + (banner_rect.width - txt.get_width()) // 2
        self.ventana.blit(txt, (tx, y + 7))
        y += 50

        txt = f_pequeña.render("Piezas en juego:", True, COLOR_TITULO)
        self.ventana.blit(txt, (px + 10, y))
        y += 22

        n1 = len(self.tablero.piezas_j1)
        n2 = len(self.tablero.piezas_j2)

        txt = f_pequeña.render(f"🔵 {NOMBRE_J1}: {n1}", True, (100, 160, 255))
        self.ventana.blit(txt, (px + 10, y))
        y += 20

        txt = f_pequeña.render(f"🔴 {NOMBRE_J2}: {n2}", True, (255, 100, 100))
        self.ventana.blit(txt, (px + 10, y))
        y += 35

        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (px + 10, y), (px + ancho_panel - 10, y), 1)
        y += 10

        txt = f_pequeña.render("Controles:", True, COLOR_TITULO)
        self.ventana.blit(txt, (px + 10, y))
        y += 22

        controles = [
            "Click → Seleccionar",
            "Click → Mover/Atacar",
            "ESC   → Menú",
        ]
        for ctrl in controles:
            txt = f_pequeña.render(ctrl, True, COLOR_TEXTO)
            self.ventana.blit(txt, (px + 10, y))
            y += 18

        y += 10

        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (px + 10, y), (px + ancho_panel - 10, y), 1)
        y += 10

        leyenda = [
            ("🟡", "Pieza seleccionada"),
            ("🟢", "Movimiento válido"),
            ("🔴", "Ataque posible"),
        ]
        for icono, desc in leyenda:
            txt = f_pequeña.render(f"{icono} {desc}", True, COLOR_TEXTO)
            self.ventana.blit(txt, (px + 10, y))
            y += 18

    #  PANTALLA DE VICTORIA

    def _dibujar_pantalla_victoria(self):
        """Muestra superposición con el ganador y botones de acción."""
        overlay = pygame.Surface((ANCHO_VENTANA, ALTO_VENTANA),
                                 pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        self.ventana.blit(overlay, (0, 0))

        cx = ANCHO_VENTANA // 2

        f_titulo  = self.fuentes["titulo"]
        f_grande  = self.fuentes["grande"]
        f_normal  = self.fuentes["normal"]

        txt = f_titulo.render("🏆 ¡VICTORIA!", True, COLOR_TITULO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 200))

        nombre_ganador = NOMBRE_J1 if self.ganador == JUGADOR_1 else NOMBRE_J2
        txt = f_grande.render(f"{nombre_ganador} ha ganado", True, COLOR_TEXTO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 270))

        txt = f_normal.render("El Rey enemigo fue eliminado", True, (200, 200, 200))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 315))

        self.btn_reiniciar = pygame.Rect(cx - 130, 370, 260, 45)
        dibujar_boton(self.ventana, "🔄  Jugar de nuevo",
                      f_normal, self.btn_reiniciar,
                      (50, 120, 50), COLOR_TEXTO, (100, 200, 100))

        self.btn_menu_vic = pygame.Rect(cx - 130, 428, 260, 45)
        dibujar_boton(self.ventana, "🏠  Menú principal",
                      f_normal, self.btn_menu_vic,
                      COLOR_BOTON, COLOR_TEXTO, COLOR_BORDE)

    def _click_pantalla_victoria(self, pos):
        """Procesa clicks en los botones de la pantalla de victoria."""
        if hasattr(self, "btn_reiniciar") and self.btn_reiniciar.collidepoint(pos):
            self._reiniciar()
            return None

        if hasattr(self, "btn_menu_vic") and self.btn_menu_vic.collidepoint(pos):
            return "menu"

        return None

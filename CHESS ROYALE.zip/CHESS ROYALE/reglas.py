"""
CLASH CHESS - Pantalla de Reglas 
"""

import pygame
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA,
    COLOR_FONDO_MENU, COLOR_TITULO, COLOR_TEXTO,
    COLOR_BOTON, COLOR_BORDE, COLOR_BOTON_HOVER,
    dibujar_boton, dibujar_texto_centrado, obtener_fuentes
)


class PantallaReglas:

    def __init__(self, ventana):
        self.ventana  = ventana
        self.fuentes  = obtener_fuentes()
        self.scroll_y = 0   # Posición del scroll vertical

        # Construir el contenido como lista de líneas
        self.contenido = self._construir_contenido()

    def _construir_contenido(self):
        return [
            # ─── ENCABEZADO ────────────────────────────────────
            ("titulo",  "📜  FICHA TÉCNICA - CLASH CHESS"),
            ("espacio", ""),
            ("texto",   "Juego de estrategia por turnos para 2 jugadores."),
            ("texto",   "Inspirado en el ajedrez clásico con temática de Clash Royale."),
            ("espacio", ""),
            ("sep",     ""),

            # ─── OBJETIVO ──────────────────────────────────────
            ("titulo",  "🎯  OBJETIVO"),
            ("espacio", ""),
            ("texto",   "Capturar el REY del jugador contrario para ganar la partida."),
            ("texto",   "No hay jaque mate: el Rey simplemente debe ser eliminado."),
            ("espacio", ""),
            ("sep",     ""),

            # ─── CÓMO JUGAR ────────────────────────────────────
            ("titulo",  "🕹  CÓMO JUGAR"),
            ("espacio", ""),
            ("texto",   "1. El Jugador 1 (Azul) siempre empieza primero."),
            ("texto",   "2. Haz click en una de tus piezas para seleccionarla."),
            ("texto",   "3. Las casillas verdes indican dónde puedes moverte."),
            ("texto",   "4. Las casillas rojas indican piezas enemigas que puedes atacar."),
            ("texto",   "5. Haz click en el destino para ejecutar el movimiento."),
            ("texto",   "6. Los turnos se alternan hasta que un Rey sea capturado."),
            ("espacio", ""),
            ("sep",     ""),

            # ─── PIEZAS ────────────────────────────────────────
            ("titulo",  "♟  PIEZAS Y MOVIMIENTOS"),
            ("espacio", ""),

            ("subtit",  "👑  REY"),
            ("texto",   "Se mueve 1 casilla en cualquier dirección (8 posibles)."),
            ("texto",   "⚠ Si tu Rey es capturado, pierdes la partida."),
            ("espacio", ""),

            ("subtit",  "🗿  GIGANTE  (Torre medieval)"),
            ("texto",   "Se mueve múltiples casillas: adelante, izquierda o derecha."),
            ("texto",   "No se mueve en diagonal. Se detiene ante piezas propias."),
            ("texto",   "Puede capturar la primera pieza enemiga que encuentre."),
            ("espacio", ""),

            ("subtit",  "🏹  PRINCESA  (Arquera a distancia)"),
            ("texto",   "Se mueve 1 casilla en cualquier dirección (solo casillas vacías)."),
            ("texto",   "Puede ATACAR a distancia hasta 3 casillas al frente en línea recta."),
            ("texto",   "El ataque se detiene al impactar con la primera pieza enemiga."),
            ("espacio", ""),

            ("subtit",  "🧙  MAGO  (Control diagonal)"),
            ("texto",   "Se mueve hasta 2 casillas en diagonal y 2 hacia adelante."),
            ("texto",   "Puede capturar piezas enemigas en esas diagonales."),
            ("texto",   "Su movimiento se bloquea si hay piezas propias en el camino."),
            ("espacio", ""),

            ("subtit",  "👺  DUENDE  (Unidad básica)"),
            ("texto",   "Avanza 1 casilla hacia adelante y hacia los lados."),
            ("texto",   "Si hay un enemigo directamente al frente, puede atacarlo."),
            ("texto",   "Es la unidad más simple pero útil para bloquear y presionar."),
            ("espacio", ""),
            ("sep",     ""),

            # ─── CONTROLES ─────────────────────────────────────
            ("titulo",  "⌨  CONTROLES"),
            ("espacio", ""),
            ("texto",   "Click izquierdo    → Seleccionar pieza / Confirmar movimiento"),
            ("texto",   "Click en otra pieza propia → Cambiar selección"),
            ("texto",   "ESC                → Volver al menú principal"),
            ("texto",   "Scroll ↑↓          → Desplazar esta pantalla"),
            ("espacio", ""),
            ("sep",     ""),

            # ─── FICHA DEL PROYECTO ────────────────────────────
            ("titulo",  "🎓  FICHA DEL PROYECTO"),
            ("espacio", ""),
            ("texto",   "Nombre     : Clash Chess - Ajedrez Táctico Medieval"),
            ("texto",   "Lenguaje   : Python 3"),
            ("texto",   "Librería   : Pygame"),
            ("texto",   "Modalidad  : 1v1 Local (mismo teclado y mouse)"),
            ("texto",   "Tablero    : 8x8 casillas"),
            ("texto",   "Turnos     : Por turno (no tiempo real)"),
            ("espacio", ""),
        ]

    def ejecutar(self):

        reloj = pygame.time.Clock()

        while True:
            mouse_pos = pygame.mouse.get_pos()

            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    return "salir"

                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_ESCAPE:
                        return "menu"
                    # Scroll con flechas de teclado
                    if evento.key == pygame.K_DOWN:
                        self.scroll_y = min(self.scroll_y + 20,
                                            self._max_scroll())
                    if evento.key == pygame.K_UP:
                        self.scroll_y = max(self.scroll_y - 20, 0)

                # Scroll con rueda del mouse
                if evento.type == pygame.MOUSEWHEEL:
                    self.scroll_y -= evento.y * 20
                    self.scroll_y = max(0, min(self.scroll_y,
                                               self._max_scroll()))

                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if evento.button == 1:
                        if self.btn_volver.collidepoint(evento.pos):
                            return "menu"

            self._dibujar(mouse_pos)
            pygame.display.flip()
            reloj.tick(60)

    def _dibujar(self, mouse_pos):
        """Renderiza la pantalla de reglas con scroll."""
        self.ventana.fill(COLOR_FONDO_MENU)
        self._dibujar_contenido()
        self._dibujar_boton_volver(mouse_pos)

    def _dibujar_contenido(self):
        """
        Dibuja cada línea del contenido aplicando el scroll.
        Las líneas fuera del área visible se omiten.
        """
        f_titulo  = self.fuentes["grande"]
        f_subtit  = self.fuentes["normal"]
        f_texto   = self.fuentes["pequeña"]

        x_margen = 60
        y        = 30 - self.scroll_y   # Offset de scroll

        alto_visible = ALTO_VENTANA - 80  # Dejar espacio al botón

        for tipo, texto in self.contenido:

            # Omitir líneas fuera del área visible (optimización)
            if y > alto_visible:
                break
            if y < -40:
                y += self._altura_linea(tipo)
                continue

            if tipo == "titulo":
                if y > 0:
                    txt = f_titulo.render(texto, True, COLOR_TITULO)
                    self.ventana.blit(txt, (x_margen, y))
                y += 40

            elif tipo == "subtit":
                if y > 0:
                    txt = f_subtit.render(texto, True, (220, 200, 255))
                    self.ventana.blit(txt, (x_margen + 10, y))
                y += 28

            elif tipo == "texto":
                if y > 0:
                    txt = f_texto.render(texto, True, COLOR_TEXTO)
                    self.ventana.blit(txt, (x_margen + 20, y))
                y += 22

            elif tipo == "espacio":
                y += 10

            elif tipo == "sep":
                if y > 0:
                    pygame.draw.line(
                        self.ventana, COLOR_BORDE,
                        (x_margen, y + 5),
                        (ANCHO_VENTANA - x_margen, y + 5), 1
                    )
                y += 20

        # Guardar la altura total para el cálculo del scroll máximo
        self._altura_total = y + self.scroll_y

    def _altura_linea(self, tipo):
        """Retorna la altura en píxeles de un tipo de línea."""
        alturas = {
            "titulo" : 40,
            "subtit" : 28,
            "texto"  : 22,
            "espacio": 10,
            "sep"    : 20,
        }
        return alturas.get(tipo, 22)

    def _max_scroll(self):
        """Calcula el máximo desplazamiento posible."""
        return max(0, getattr(self, "_altura_total", 0) - ALTO_VENTANA + 100)

    def _dibujar_boton_volver(self, mouse_pos):
        """Dibuja el botón fijo en la parte inferior para volver al menú."""
        f_normal = self.fuentes["normal"]

        self.btn_volver = pygame.Rect(
            ANCHO_VENTANA // 2 - 120,
            ALTO_VENTANA - 60,
            240, 44
        )

        hover = self.btn_volver.collidepoint(mouse_pos)
        color = (70, 55, 100) if hover else COLOR_BOTON

        # Fondo opaco detrás del botón para legibilidad
        bg = pygame.Rect(0, ALTO_VENTANA - 75, ANCHO_VENTANA, 75)
        pygame.draw.rect(self.ventana, COLOR_FONDO_MENU, bg)
        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (0, ALTO_VENTANA - 75),
                         (ANCHO_VENTANA, ALTO_VENTANA - 75), 1)

        dibujar_boton(
            self.ventana, "← Volver al Menú",
            f_normal, self.btn_volver,
            color, COLOR_TEXTO, COLOR_BORDE
        )

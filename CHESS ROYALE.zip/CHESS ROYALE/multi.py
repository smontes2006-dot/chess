"""
CLASH CHESS - Pantalla de Configuración Multijugador
"""

import pygame
import threading
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA,
    COLOR_FONDO_MENU, COLOR_TITULO, COLOR_TEXTO,
    COLOR_BOTON, COLOR_BOTON_HOVER, COLOR_BORDE,
    COLOR_FONDO_UI,
    dibujar_boton, obtener_fuentes
)
from red import Red

# Constante local para identificar jugadores
JUGADOR_1 = 1
JUGADOR_2 = 2


class PantallaMulti:
    """
    Pantalla de lobby para el modo online.
    """

    def __init__(self, ventana):
        self.ventana  = ventana
        self.fuentes  = obtener_fuentes()
        self.estado   = "inicio"

        # Texto del campo de IP (modo cliente)
        self.ip_texto    = ""
        self.ip_activo   = False   # True cuando el campo de IP tiene foco

        # Mensaje de estado visible al usuario
        self.msg_estado  = ""

        # Resultado de la conexión (se llena en hilo paralelo)
        self.red          = None
        self.num_jugador  = None
        self.conexion_ok  = False

        # Rectángulos de botones (se calculan en _dibujar)
        self.btn_servidor = None
        self.btn_cliente  = None
        self.btn_volver   = None
        self.btn_conectar = None
        self.campo_ip     = None

    def ejecutar(self):
        """
        Bucle de la pantalla de lobby.
        """
        reloj = pygame.time.Clock()

        while True:
            mouse_pos = pygame.mouse.get_pos()

            for evento in pygame.event.get():

                if evento.type == pygame.QUIT:
                    return ("salir", None, None)

                if evento.type == pygame.KEYDOWN:

                    if evento.key == pygame.K_ESCAPE:
                        return ("menu", None, None)

                    # Escritura en el campo de IP
                    if self.estado == "cliente" and self.ip_activo:

                        if evento.key == pygame.K_BACKSPACE:
                            self.ip_texto = self.ip_texto[:-1]

                        elif evento.key == pygame.K_RETURN:
                            self._intentar_conectar_cliente()

                        elif len(self.ip_texto) < 15:
                            # Solo caracteres válidos para una IP
                            if evento.unicode in "0123456789.":
                                self.ip_texto += evento.unicode

                if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                    resultado = self._manejar_click(evento.pos)
                    if resultado:
                        return resultado

            # Si la conexión se estableció en el hilo, retornar
            if self.conexion_ok and self.red and self.num_jugador:
                return ("juego_online", self.red, self.num_jugador)

            self._dibujar(mouse_pos)
            pygame.display.flip()
            reloj.tick(60)

    def _manejar_click(self, pos):
        """Procesa clicks según el estado actual."""
        if self.estado == "inicio":

            if self.btn_servidor and self.btn_servidor.collidepoint(pos):
                self.estado     = "servidor"
                self.msg_estado = "Esperando al jugador 2..."
                # Arrancar servidor en hilo para no bloquear Pygame
                threading.Thread(
                    target=self._arrancar_servidor,
                    daemon=True
                ).start()

            elif self.btn_cliente and self.btn_cliente.collidepoint(pos):
                self.estado     = "cliente"
                self.msg_estado = "Ingresa la IP del servidor"

            elif self.btn_volver and self.btn_volver.collidepoint(pos):
                return ("menu", None, None)

        # ── Estado: campo de IP (cliente) ───────────────────────
        elif self.estado == "cliente":

            if self.campo_ip and self.campo_ip.collidepoint(pos):
                self.ip_activo = True   # Activar escritura

            elif self.btn_conectar and self.btn_conectar.collidepoint(pos):
                self._intentar_conectar_cliente()

            elif self.btn_volver and self.btn_volver.collidepoint(pos):
                # Volver a la pantalla de inicio
                self.estado    = "inicio"
                self.ip_texto  = ""
                self.ip_activo = False
                self.msg_estado = ""

            else:
                self.ip_activo = False   # Click fuera del campo

        # ── Estado: error → reintentar ──────────────────────────
        elif self.estado == "error":
            if self.btn_volver and self.btn_volver.collidepoint(pos):
                self.estado     = "inicio"
                self.msg_estado = ""

        return None
    #  LÓGICA DE CONEXIÓN

    def _arrancar_servidor(self):
        """
        Hilo del servidor: espera al cliente y marca
        conexion_ok cuando se conecta.
        """
        try:
            red = Red()
            red.iniciar_servidor(puerto=5555)   # Bloquea hasta conexión
            self.red         = red
            self.num_jugador = JUGADOR_1
            self.conexion_ok = True
            self.msg_estado  = "¡Jugador 2 conectado! Iniciando..."
        except Exception as e:
            self.estado     = "error"
            self.msg_estado = f"Error al abrir servidor: {e}"

    def _intentar_conectar_cliente(self):
        """
        Valida la IP y lanza el hilo de conexión como cliente.
        """
        ip = self.ip_texto.strip()

        if not ip:
            self.msg_estado = "Escribe la IP primero"
            return

        self.estado     = "conectando"
        self.msg_estado = f"Conectando a {ip}..."

        threading.Thread(
            target=self._conectar_cliente,
            args=(ip,),
            daemon=True
        ).start()

    def _conectar_cliente(self, ip):
        """
        Hilo del cliente: intenta conectarse al servidor.
        """
        try:
            red = Red()
            red.conectar(ip, puerto=5555)
            self.red         = red
            self.num_jugador = JUGADOR_2
            self.conexion_ok = True
            self.msg_estado  = "¡Conectado! Iniciando partida..."
        except Exception as e:
            self.estado     = "error"
            self.msg_estado = f"No se pudo conectar: {e}"

    #  DIBUJO

    def _dibujar(self, mouse_pos):
        """Renderiza la pantalla según el estado actual."""
        self.ventana.fill(COLOR_FONDO_MENU)

        cx = ANCHO_VENTANA // 2
        f_titulo  = self.fuentes["titulo"]
        f_grande  = self.fuentes["grande"]
        f_normal  = self.fuentes["normal"]
        f_pequeña = self.fuentes["pequeña"]

        # ── Título ──────────────────────────────────────────────
        txt = f_titulo.render("🌐  MODO ONLINE", True, COLOR_TITULO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 80))

        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (cx - 200, 140), (cx + 200, 140), 2)

        # ── Contenido según estado ───────────────────────────────
        if self.estado == "inicio":
            self._dibujar_inicio(mouse_pos, cx, f_grande, f_normal)

        elif self.estado in ("servidor", "conectando"):
            self._dibujar_esperando(cx, f_grande, f_normal)

        elif self.estado == "cliente":
            self._dibujar_cliente(mouse_pos, cx, f_grande, f_normal, f_pequeña)

        elif self.estado == "error":
            self._dibujar_error(mouse_pos, cx, f_grande, f_normal)

        # ── Mensaje de estado (siempre visible abajo) ───────────
        if self.msg_estado:
            txt = f_pequeña.render(self.msg_estado, True, (200, 200, 140))
            self.ventana.blit(txt, (cx - txt.get_width() // 2, ALTO_VENTANA - 60))

    def _dibujar_inicio(self, mouse_pos, cx, f_grande, f_normal):
        """Dibuja los botones de la pantalla de inicio."""
        ancho = 280
        alto  = 55

        # Botón Servidor (Jugador 1)
        self.btn_servidor = pygame.Rect(cx - ancho // 2, 200, ancho, alto)
        hover = self.btn_servidor.collidepoint(mouse_pos)
        dibujar_boton(self.ventana, "🖥  CREAR PARTIDA (J1)",
                      f_normal, self.btn_servidor,
                      COLOR_BOTON_HOVER if hover else COLOR_BOTON,
                      COLOR_TEXTO, COLOR_BORDE)

        # Descripción
        txt = self.fuentes["pequeña"].render(
            "Abre un servidor · Eres el Jugador 1 (Azul)",
            True, (160, 160, 160))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 262))

        # Botón Cliente (Jugador 2)
        self.btn_cliente = pygame.Rect(cx - ancho // 2, 295, ancho, alto)
        hover = self.btn_cliente.collidepoint(mouse_pos)
        dibujar_boton(self.ventana, "🔌  UNIRSE A PARTIDA (J2)",
                      f_normal, self.btn_cliente,
                      COLOR_BOTON_HOVER if hover else COLOR_BOTON,
                      COLOR_TEXTO, COLOR_BORDE)

        txt = self.fuentes["pequeña"].render(
            "Ingresa la IP del servidor · Eres el Jugador 2 (Rojo)",
            True, (160, 160, 160))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 357))

        # Botón Volver
        self.btn_volver = pygame.Rect(cx - 120, 410, 240, 44)
        hover = self.btn_volver.collidepoint(mouse_pos)
        dibujar_boton(self.ventana, "← Volver",
                      f_normal, self.btn_volver,
                      COLOR_BOTON_HOVER if hover else COLOR_BOTON,
                      COLOR_TEXTO, COLOR_BORDE)

    def _dibujar_esperando(self, cx, f_grande, f_normal):
        """Dibuja animación de espera."""
        txt = f_grande.render("⏳  Esperando conexión...", True, COLOR_TITULO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 240))

        txt = f_normal.render(
            "Comparte tu IP local con el otro jugador",
            True, COLOR_TEXTO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 300))

        txt = self.fuentes["pequeña"].render(
            "Tip: en Windows usa 'ipconfig', en Mac/Linux usa 'ifconfig'",
            True, (150, 150, 150))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 340))

        # Botón cancelar queda como Volver al inicio
        self.btn_volver = None   # Desactivado mientras espera

    def _dibujar_cliente(self, mouse_pos, cx, f_grande, f_normal, f_pequeña):
        """Dibuja el campo de IP y el botón de conectar."""
        txt = f_grande.render("Ingresa la IP del servidor:", True, COLOR_TITULO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 190))

        # Campo de texto para la IP
        self.campo_ip = pygame.Rect(cx - 150, 250, 300, 44)
        color_campo = (80, 70, 110) if self.ip_activo else COLOR_FONDO_UI
        pygame.draw.rect(self.ventana, color_campo,
                         self.campo_ip, border_radius=8)
        pygame.draw.rect(self.ventana, COLOR_BORDE,
                         self.campo_ip, 2, border_radius=8)

        # Texto dentro del campo (con cursor parpadeante)
        display_ip = self.ip_texto + ("|" if self.ip_activo else "")
        txt = f_normal.render(display_ip or "Ej: 192.168.1.5",
                              True,
                              COLOR_TEXTO if self.ip_texto else (100, 100, 100))
        self.ventana.blit(txt, (self.campo_ip.x + 10,
                                self.campo_ip.y + 10))

        # Botón Conectar
        self.btn_conectar = pygame.Rect(cx - 120, 318, 240, 46)
        hover = self.btn_conectar.collidepoint(mouse_pos)
        dibujar_boton(self.ventana, "🔌  Conectar",
                      f_normal, self.btn_conectar,
                      COLOR_BOTON_HOVER if hover else COLOR_BOTON,
                      COLOR_TEXTO, COLOR_BORDE)

        # Botón Volver
        self.btn_volver = pygame.Rect(cx - 120, 385, 240, 44)
        hover = self.btn_volver.collidepoint(mouse_pos)
        dibujar_boton(self.ventana, "← Volver",
                      f_normal, self.btn_volver,
                      COLOR_BOTON_HOVER if hover else COLOR_BOTON,
                      COLOR_TEXTO, COLOR_BORDE)

    def _dibujar_error(self, mouse_pos, cx, f_grande, f_normal):
        """Dibuja el mensaje de error y el botón de reintentar."""
        txt = f_grande.render("❌  Error de conexión", True, (255, 80, 80))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 230))

        # Botón volver a intentar
        self.btn_volver = pygame.Rect(cx - 130, 320, 260, 46)
        hover = self.btn_volver.collidepoint(mouse_pos)
        dibujar_boton(self.ventana, "🔄  Reintentar",
                      f_normal, self.btn_volver,
                      COLOR_BOTON_HOVER if hover else COLOR_BOTON,
                      COLOR_TEXTO, COLOR_BORDE)

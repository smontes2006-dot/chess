"""
CLASH CHESS - Módulo del Tablero
"""

import pygame
from piezas import Rey, Gigante, Princesa, Mago, Duende
from utils import (
    FILAS, COLUMNAS, TAMANO_CASILLA, MARGEN_IZQ, MARGEN_SUP,
    COLOR_CASILLA_CLARA, COLOR_CASILLA_OSCURA,
    COLOR_SELECCION, COLOR_MOVIMIENTO, COLOR_ATAQUE,
    COLOR_BORDE, JUGADOR_1, JUGADOR_2,
    fila_col_a_pixel
)


class Tablero:
    """
    Clase que representa el tablero de juego 8x8.
    """

    def __init__(self):
        """Inicializa el tablero vacío y coloca las piezas."""
        # Cuadrícula 8x8 inicializada con None (vacía)
        self.cuadricula = [[None] * COLUMNAS for _ in range(FILAS)]

        # Listas de piezas por jugador (para fácil acceso)
        self.piezas_j1 = []
        self.piezas_j2 = []

        # Colocar las piezas en sus posiciones iniciales
        self._inicializar_piezas()

    def _inicializar_piezas(self):
        """
        Coloca todas las piezas en el tablero al inicio
        de la partida.
        """

        # --- JUGADOR 2 (arriba, filas 0-1) ---
        piezas_fila_0_j2 = [
            Gigante  (0, 0, JUGADOR_2),
            Mago     (0, 1, JUGADOR_2),
            Princesa (0, 2, JUGADOR_2),
            Rey      (0, 4, JUGADOR_2),
            Princesa (0, 5, JUGADOR_2),
            Mago     (0, 6, JUGADOR_2),
            Gigante  (0, 7, JUGADOR_2),
        ]

        duendes_j2 = [Duende(1, c, JUGADOR_2) for c in range(8)]

        # --- JUGADOR 1 (abajo, filas 6-7) ---
        piezas_fila_7_j1 = [
            Gigante  (7, 0, JUGADOR_1),
            Mago     (7, 1, JUGADOR_1),
            Princesa (7, 2, JUGADOR_1),
            Rey      (7, 4, JUGADOR_1),
            Princesa (7, 5, JUGADOR_1),
            Mago     (7, 6, JUGADOR_1),
            Gigante  (7, 7, JUGADOR_1),
        ]

        duendes_j1 = [Duende(6, c, JUGADOR_1) for c in range(8)]

        # Registrar todas las piezas en cuadrícula y listas
        todas = (piezas_fila_0_j2 + duendes_j2 +
                 piezas_fila_7_j1 + duendes_j1)

        for pieza in todas:
            self._colocar_pieza(pieza)

    def _colocar_pieza(self, pieza):
        """
        Registra una pieza en la cuadrícula y en la lista
        del jugador correspondiente.

        Args:
            pieza (Pieza): La pieza a colocar.
        """
        self.cuadricula[pieza.fila][pieza.col] = pieza

        if pieza.jugador == JUGADOR_1:
            self.piezas_j1.append(pieza)
        else:
            self.piezas_j2.append(pieza)

    def obtener_pieza(self, fila, col):
        """
        Retorna la pieza en una casilla, o None si está vacía.
        """
        return self.cuadricula[fila][col]

    def hay_rey(self, jugador):
        """
        Verifica si el Rey de un jugador sigue vivo.
        """
        lista = self.piezas_j1 if jugador == JUGADOR_1 else self.piezas_j2
        return any(isinstance(p, Rey) and p.viva for p in lista)

    def verificar_victoria(self):
        """
        Comprueba si algún jugador ha ganado la partida.
        La condición de victoria es capturar el Rey enemigo.
        """
        if not self.hay_rey(JUGADOR_2):
            return JUGADOR_1
        if not self.hay_rey(JUGADOR_1):
            return JUGADOR_2
        return None

    def mover_pieza(self, pieza, nueva_fila, nueva_col):
        """
        Mueve una pieza a una nueva casilla.
        Si hay una pieza enemiga en el destino, la captura.
        """
        pieza_capturada = None

        # Verificar si hay una pieza en el destino
        ocupante = self.cuadricula[nueva_fila][nueva_col]
        if ocupante is not None:
            # Capturar la pieza enemiga
            ocupante.viva = False
            pieza_capturada = ocupante

            # Removerla de la lista de su jugador
            if ocupante.jugador == JUGADOR_1:
                self.piezas_j1.remove(ocupante)
            else:
                self.piezas_j2.remove(ocupante)

        # Liberar la casilla original
        self.cuadricula[pieza.fila][pieza.col] = None

        # Actualizar la posición de la pieza
        pieza.fila = nueva_fila
        pieza.col  = nueva_col

        # Registrar en la nueva casilla
        self.cuadricula[nueva_fila][nueva_col] = pieza

        return pieza_capturada


    def dibujar(self, superficie, pieza_sel=None, movimientos_validos=None):
        """
        Dibuja el tablero completo: casillas, resaltados y piezas.
        """
        if movimientos_validos is None:
            movimientos_validos = []

        self._dibujar_casillas(superficie)
        self._dibujar_coordenadas(superficie)
        self._dibujar_resaltados(superficie, pieza_sel, movimientos_validos)
        self._dibujar_piezas(superficie, pieza_sel)
        self._dibujar_borde(superficie)

    def _dibujar_casillas(self, superficie):
        """Pinta el patrón de ajedrez (casillas claras y oscuras)."""
        for fila in range(FILAS):
            for col in range(COLUMNAS):
                x, y = fila_col_a_pixel(fila, col)

                # Casillas claras en posiciones par+par o impar+impar
                if (fila + col) % 2 == 0:
                    color = COLOR_CASILLA_CLARA
                else:
                    color = COLOR_CASILLA_OSCURA

                pygame.draw.rect(superficie, color,
                                 (x, y, TAMANO_CASILLA, TAMANO_CASILLA))

    def _dibujar_coordenadas(self, superficie):
        """
        Dibuja las letras (A-H) y números (1-8) en los
        bordes del tablero para referencia visual.
        """
        fuente = pygame.font.SysFont("Georgia", 13)
        letras = "ABCDEFGH"

        for i in range(8):
            # Letras de columnas (abajo del tablero)
            x = MARGEN_IZQ + i * TAMANO_CASILLA + TAMANO_CASILLA // 2 - 5
            y = MARGEN_SUP + ALTO_TABLERO + 5
            txt = fuente.render(letras[i], True, (200, 180, 140))
            superficie.blit(txt, (x, y))

            # Números de filas (a la izquierda del tablero)
            x = MARGEN_IZQ - 20
            y = MARGEN_SUP + i * TAMANO_CASILLA + TAMANO_CASILLA // 2 - 8
            txt = fuente.render(str(8 - i), True, (200, 180, 140))
            superficie.blit(txt, (x, y))

    def _dibujar_resaltados(self, superficie, pieza_sel, movimientos_validos):
        """
        Dibuja los resaltados visuales:
        """
        # Superficie auxiliar para transparencia
        capa = pygame.Surface((TAMANO_CASILLA, TAMANO_CASILLA), pygame.SRCALPHA)

        # Resaltar la pieza seleccionada (amarillo)
        if pieza_sel:
            x, y = fila_col_a_pixel(pieza_sel.fila, pieza_sel.col)
            capa.fill(COLOR_SELECCION)
            superficie.blit(capa, (x, y))

        # Resaltar movimientos disponibles
        for fila, col in movimientos_validos:
            x, y = fila_col_a_pixel(fila, col)
            pieza_ahi = self.obtener_pieza(fila, col)

            if pieza_ahi and pieza_ahi.jugador != (pieza_sel.jugador if pieza_sel else -1):
                # Casilla con enemigo: rojo
                capa.fill(COLOR_ATAQUE)
            else:
                # Casilla vacía: verde
                capa.fill(COLOR_MOVIMIENTO)

            superficie.blit(capa, (x, y))

    def _dibujar_piezas(self, superficie, pieza_sel):
        """
        Dibuja todas las piezas vivas del tablero.
        La pieza seleccionada recibe un indicador visual extra.
        """
        for fila in range(FILAS):
            for col in range(COLUMNAS):
                pieza = self.cuadricula[fila][col]
                if pieza and pieza.viva:
                    seleccionada = (pieza == pieza_sel)
                    pieza.dibujar(superficie, seleccionada)

    def _dibujar_borde(self, superficie):
        """Dibuja un borde decorativo alrededor del tablero."""
        rect_tablero = pygame.Rect(
            MARGEN_IZQ - 2,
            MARGEN_SUP - 2,
            ANCHO_TABLERO + 4,
            ALTO_TABLERO + 4
        )
        pygame.draw.rect(superficie, COLOR_BORDE, rect_tablero, 3)


# Importación local para evitar circularidad en imports
from utils import ANCHO_TABLERO, ALTO_TABLERO

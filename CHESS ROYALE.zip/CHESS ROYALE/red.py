"""
CLASH CHESS - Módulo de Red
"""

import socket
import threading
import json


class Red:

    def __init__(self):
        self.socket    = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.conectado = False
        self.mensajes  = []          # Cola de mensajes/movimientos recibidos
        self._buffer   = ""          # Buffer interno para paquetes parciales

    def iniciar_servidor(self, puerto=5555):

        # Permite reutilizar el puerto inmediatamente tras cerrar
        self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self.socket.bind(("0.0.0.0", puerto))
        self.socket.listen(1)

        print("Esperando jugador...")

        self.conn, addr = self.socket.accept()

        print("Jugador conectado:", addr)

        self.conectado = True

        threading.Thread(
            target=self._recibir_loop,
            daemon=True
        ).start()

    def conectar(self, ip, puerto=5555):

        self.socket.connect((ip, puerto))
        self.conn      = self.socket
        self.conectado = True

        print("Conectado al servidor")

        threading.Thread(
            target=self._recibir_loop,
            daemon=True
        ).start()


    def enviar_movimiento(self, origen, destino):
        """
        Serializa un movimiento como JSON y lo envía.
        """
        datos = {
            "origen":  list(origen),
            "destino": list(destino)
        }
        # Se añade "\n" como delimitador de paquete
        self._enviar_raw(json.dumps(datos) + "\n")


    def enviar(self, mensaje):
        """Envía un string genérico (usado por servidor.py y cliente.py)."""
        if self.conectado:
            # Se empaqueta también con "\n" para consistencia
            self._enviar_raw(json.dumps({"texto": mensaje}) + "\n")

    def _enviar_raw(self, texto):
        """Envía bytes por el socket. Maneja errores de conexión."""
        if self.conectado:
            try:
                self.conn.sendall(texto.encode("utf-8"))
            except Exception:
                self.conectado = False
    def _recibir_loop(self):

        while self.conectado:
            try:
                chunk = self.conn.recv(4096).decode("utf-8")

                if not chunk:
                    # Conexión cerrada por el otro extremo
                    self.conectado = False
                    break

                self._buffer += chunk

                # Procesar todos los mensajes completos del buffer
                while "\n" in self._buffer:
                    linea, self._buffer = self._buffer.split("\n", 1)
                    linea = linea.strip()
                    if linea:
                        try:
                            datos = json.loads(linea)
                            self.mensajes.append(datos)
                        except json.JSONDecodeError:
                            pass   # Ignorar paquetes malformados

            except Exception:
                self.conectado = False
                break

    def recibir_mensajes(self):
        """Alias del loop de recepción (por si algo lo llama directamente)."""
        self._recibir_loop()

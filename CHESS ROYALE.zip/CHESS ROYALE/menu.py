"""
CLASH CHESS - Menú Principal
"""

import pygame
import math
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA,
    COLOR_FONDO_MENU, COLOR_TITULO, COLOR_TEXTO,
    COLOR_BOTON, COLOR_BOTON_HOVER, COLOR_BORDE,
    dibujar_boton, obtener_fuentes
)


class MenuPrincipal:
    """
    Pantalla del menú principal del juego.
    """

    def __init__(self, ventana):
        self.ventana = ventana
        self.fuentes = obtener_fuentes()
        self.tiempo  = 0   # Contador de frames para animaciones

    #  BUCLE PRINCIPAL DEL MENÚ

    def ejecutar(self):
        """
        Bucle de la pantalla del menú. Espera input del usuario.
        """
        reloj = pygame.time.Clock()

        while True:
            self.tiempo += 1
            mouse_pos = pygame.mouse.get_pos()

            # --- Gestión de eventos ---
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    return "salir"

                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if evento.button == 1:
                        resultado = self._verificar_click(evento.pos)
                        if resultado:
                            return resultado

            # --- Dibujo ---
            self._dibujar(mouse_pos)
            pygame.display.flip()
            reloj.tick(60)

    #  VERIFICACIÓN DE CLICKS


    def _verificar_click(self, pos):
        

            if self.btn_jugar.collidepoint(pos):
                return "juego"

            if self.btn_multi.collidepoint(pos):
                return "multi"

            if self.btn_reglas.collidepoint(pos):
                return "reglas"

            if self.btn_salir.collidepoint(pos):
                return "salir"

            return None

    #  DIBUJO DEL MENÚ

    def _dibujar(self, mouse_pos):
        """Renderiza todos los elementos del menú."""
        # Fondo degradado oscuro
        self.ventana.fill(COLOR_FONDO_MENU)
        self._dibujar_fondo_decorativo()
        self._dibujar_titulo()
        self._dibujar_botones(mouse_pos)
        self._dibujar_pie()

    def _dibujar_fondo_decorativo(self):
        """
        Dibuja elementos decorativos de fondo: círculos tenues
        que oscilan con el tiempo para dar sensación de vida.
        """
        # Círculos decorativos pulsantes (sin importar librerías extra)
        for i in range(5):
            pulso = math.sin(self.tiempo * 0.02 + i * 1.2)
            radio = int(40 + 15 * pulso + i * 30)
            alpha = max(10, int(25 + 10 * pulso))

            # Crear superficie transparente para cada círculo
            circ = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
            pygame.draw.circle(circ, (100, 70, 150, alpha),
                               (radio, radio), radio)

            cx = [150, 750, 450, 80, 820][i]
            cy = [150, 100, 500, 550, 450][i]
            self.ventana.blit(circ, (cx - radio, cy - radio))

    def _dibujar_titulo(self):
        """Dibuja el título principal y el subtítulo del juego."""
        f_titulo  = self.fuentes["titulo"]
        f_normal  = self.fuentes["normal"]
        cx = ANCHO_VENTANA // 2

        # Icono decorativo superior
        f_emoji = self.fuentes["emoji"]
        iconos = "⚔️  👑  🏰"
        txt = f_emoji.render(iconos, True, COLOR_TITULO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 100))

        # Título principal con efecto de brillo
        titulo = "CLASH  CHESS"
        txt_titulo = f_titulo.render(titulo, True, COLOR_TITULO)
        self.ventana.blit(txt_titulo, (cx - txt_titulo.get_width() // 2, 155))

        # Línea dorada decorativa
        largo = 300
        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (cx - largo // 2, 215), (cx + largo // 2, 215), 2)

        # Subtítulo
        sub = "Ajedrez Táctico Clash Royale"
        txt_sub = f_normal.render(sub, True, (200, 180, 140))
        self.ventana.blit(txt_sub, (cx - txt_sub.get_width() // 2, 225))

    def _dibujar_botones(self, mouse_pos):
        """
        Dibuja los tres botones del menú con efecto hover.
        """
        cx = ANCHO_VENTANA // 2
        f_grande = self.fuentes["grande"]
        f_normal = self.fuentes["normal"]

        ancho_btn = 280
        alto_btn  = 55
        x_btn     = cx - ancho_btn // 2

        # Definir los tres botones y sus posiciones
        botones_info = [
            ("⚔  JUGAR",        260, "jugar"),
            ("🌐  ONLINE", 410, "multi"),
            ("📖  REGLAS",       485, "reglas"),
            ("🚪  SALIR",        560, "salir"),
        ]

        for etiqueta, y, clave in botones_info:
            rect = pygame.Rect(x_btn, y, ancho_btn, alto_btn)

            # Cambiar color si el mouse está encima (hover)
            hover = rect.collidepoint(mouse_pos)
            color_fondo = COLOR_BOTON_HOVER if hover else COLOR_BOTON

            dibujar_boton(
                self.ventana, etiqueta, f_grande,
                rect, color_fondo, COLOR_TEXTO,
                COLOR_BORDE, radio=10
            )

            # Guardar las referencias de los botones para detectar clicks
            if clave == "jugar":
                self.btn_jugar = rect

            elif clave == "multi":
                self.btn_multi = rect

            elif clave == "reglas":
                self.btn_reglas = rect

            elif clave == "salir":
                self.btn_salir = rect

    def _dibujar_pie(self):
        """Dibuja una nota pequeña al pie de la pantalla."""
        f_pequeña = self.fuentes["pequeña"]
        txt = f_pequeña.render(
            "Proyecto Universitario  |  Python + Pygame  |  Juego por Turnos",
            True, (100, 90, 120)
        )
        cx = ANCHO_VENTANA // 2
        self.ventana.blit(txt,
                          (cx - txt.get_width() // 2, ALTO_VENTANA - 30))

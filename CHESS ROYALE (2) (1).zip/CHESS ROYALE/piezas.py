"""
CLASH CHESS - Módulo de Piezas
"""

import pygame
from utils import (TAMANO_CASILLA, COLOR_PIEZA_J1, COLOR_PIEZA_J2,
                   COLOR_PIEZA_BORDE, fila_col_a_pixel,
                   JUGADOR_1, JUGADOR_2)

class Pieza:
    """
    Clase base de la que heredan todas las piezas del juego.
    """

    def __init__(self, fila, col, jugador, nombre, simbolo):
        self.fila    = fila
        self.col     = col
        self.jugador = jugador
        self.nombre  = nombre
        self.simbolo = simbolo
        self.viva    = True

    def obtener_movimientos(self, tablero):
        raise NotImplementedError(
            f"{self.nombre} debe implementar obtener_movimientos()"
        )

    def dibujar(self, superficie, seleccionada=False):
        x, y = fila_col_a_pixel(self.fila, self.col)
        cx = x + TAMANO_CASILLA // 2
        cy = y + TAMANO_CASILLA // 2
        radio = TAMANO_CASILLA // 2 - 6

        color_fill  = COLOR_PIEZA_J1 if self.jugador == JUGADOR_1 else COLOR_PIEZA_J2
        color_borde = COLOR_PIEZA_BORDE

        pygame.draw.circle(superficie, (0, 0, 0, 80), (cx + 2, cy + 3), radio)
        pygame.draw.circle(superficie, color_fill, (cx, cy), radio)
        pygame.draw.circle(superficie, color_borde, (cx, cy), radio, 2)

        if seleccionada:
            pygame.draw.circle(superficie, (255, 220, 0), (cx, cy), radio, 3)

        fuente = pygame.font.SysFont("Segoe UI Emoji", 22)
        render_sim = fuente.render(self.simbolo, True, (255, 255, 255))
        sx = cx - render_sim.get_width()  // 2
        sy = cy - render_sim.get_height() // 2
        superficie.blit(render_sim, (sx, sy))

    def _es_valida(self, fila, col):
        return 0 <= fila < 8 and 0 <= col < 8

    def _casilla_libre_o_enemiga(self, fila, col, tablero):
        pieza = tablero.obtener_pieza(fila, col)
        return pieza is None or pieza.jugador != self.jugador

    def _es_enemigo(self, fila, col, tablero):
        pieza = tablero.obtener_pieza(fila, col)
        return pieza is not None and pieza.jugador != self.jugador

    def __repr__(self):
        return f"{self.nombre}(J{self.jugador}, fila={self.fila}, col={self.col})"


# ─────────────────────────────────────────────
#  PIEZA: Rey
# ─────────────────────────────────────────────

class Rey(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Rey", "👑")

    def obtener_movimientos(self, tablero):
        movimientos = []
        direcciones = [
            (-1, -1), (-1, 0), (-1, 1),
            ( 0, -1),          ( 0, 1),
            ( 1, -1), ( 1, 0), ( 1, 1),
        ]
        for df, dc in direcciones:
            nf = self.fila + df
            nc = self.col  + dc
            if self._es_valida(nf, nc) and self._casilla_libre_o_enemiga(nf, nc, tablero):
                movimientos.append((nf, nc))
        return movimientos


# ─────────────────────────────────────────────
#  PIEZA: Gigante
# ─────────────────────────────────────────────

class Gigante(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Gigante", "🗿")

    def obtener_movimientos(self, tablero):
        movimientos = []
        adelante = -1 if self.jugador == JUGADOR_1 else 1

        direcciones_lineales = [
            (adelante,  0),
            (0,        -1),
            (0,         1),
        ]

        for df, dc in direcciones_lineales:
            nf, nc = self.fila + df, self.col + dc
            while self._es_valida(nf, nc):
                pieza_en_casilla = tablero.obtener_pieza(nf, nc)
                if pieza_en_casilla is None:
                    movimientos.append((nf, nc))
                elif pieza_en_casilla.jugador != self.jugador:
                    movimientos.append((nf, nc))
                    break
                else:
                    break
                nf += df
                nc += dc

        return movimientos


# ─────────────────────────────────────────────
#  PIEZA: Princesa
# ─────────────────────────────────────────────

class Princesa(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Princesa", "🏹")

    def obtener_movimientos(self, tablero):
        movimientos = []
        adelante = -1 if self.jugador == JUGADOR_1 else 1

        for df in [-1, 0, 1]:
            for dc in [-1, 0, 1]:
                if df == 0 and dc == 0:
                    continue
                nf = self.fila + df
                nc = self.col  + dc
                if self._es_valida(nf, nc) and self._casilla_libre_o_enemiga(nf, nc, tablero):
                    pieza = tablero.obtener_pieza(nf, nc)
                    if pieza is None:
                        movimientos.append((nf, nc))

        for distancia in range(1, 4):
            nf = self.fila + adelante * distancia
            nc = self.col
            if not self._es_valida(nf, nc):
                break
            pieza = tablero.obtener_pieza(nf, nc)
            if pieza is None:
                continue
            elif pieza.jugador != self.jugador:
                movimientos.append((nf, nc))
                break
            else:
                break

        return movimientos


# ─────────────────────────────────────────────
#  PIEZA: Mago
#  Movimiento: hasta 2 casillas en diagonal
#  hacia adelante + hasta 2 casillas recto
#  hacia adelante. NO puede retroceder.
# ─────────────────────────────────────────────

class Mago(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Mago", "🧙")

    def obtener_movimientos(self, tablero):
        movimientos = []
        # adelante = dirección de avance según jugador
        # J1 sube  → adelante = -1
        # J2 baja  → adelante = +1
        adelante = -1 if self.jugador == JUGADOR_1 else 1

        # Solo las diagonales hacia adelante y el recto hacia adelante.
        # Se excluyen las diagonales hacia atrás (adelante opuesto).
        direcciones = [
            (adelante, -1),   # diagonal adelante-izquierda
            (adelante,  1),   # diagonal adelante-derecha
            (adelante,  0),   # recto hacia adelante
        ]

        for df, dc in direcciones:
            for paso in range(1, 3):   # máximo 2 casillas por dirección
                nf = self.fila + df * paso
                nc = self.col  + dc * paso

                if not self._es_valida(nf, nc):
                    break

                pieza = tablero.obtener_pieza(nf, nc)

                if pieza is None:
                    movimientos.append((nf, nc))
                elif pieza.jugador != self.jugador:
                    movimientos.append((nf, nc))
                    break   # Captura pero no pasa
                else:
                    break   # Pieza propia bloquea

        return movimientos


# ─────────────────────────────────────────────
#  PIEZA: Duende
# ─────────────────────────────────────────────

class Duende(Pieza):

    def __init__(self, fila, col, jugador):
        super().__init__(fila, col, jugador, "Duende", "👺")

    def obtener_movimientos(self, tablero):
        movimientos = []
        adelante = -1 if self.jugador == JUGADOR_1 else 1

        direcciones = [
            (adelante, 0),
            (0, -1),
            (0,  1),
        ]

        for df, dc in direcciones:
            nf = self.fila + df
            nc = self.col  + dc
            if not self._es_valida(nf, nc):
                continue
            pieza = tablero.obtener_pieza(nf, nc)
            if pieza is None or pieza.jugador != self.jugador:
                movimientos.append((nf, nc))

        return movimientos

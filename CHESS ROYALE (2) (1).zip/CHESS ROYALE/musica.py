"""
CLASH CHESS - Módulo de Música
Maneja la música de fondo de forma centralizada.
"""

import pygame
import os


class GestorMusica:
    """
    Gestiona la música de fondo del juego.
    Singleton para que toda la app comparta el mismo estado.
    """

    _instancia = None

    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super().__new__(cls)
            cls._instancia._inicializado = False
        return cls._instancia

    def __init__(self):
        if self._inicializado:
            return
        self._inicializado = True
        self.activa        = True   # Música encendida por defecto
        self.volumen       = 0.5    # Volumen al 50%
        self._cargada      = False
        self._intentar_cargar()

    def _intentar_cargar(self):
        """Intenta cargar musica.mp3 desde el directorio actual."""
        rutas_posibles = [
            "musica.mp3",
            os.path.join(os.path.dirname(__file__), "musica.mp3"),
            os.path.join(os.getcwd(), "musica.mp3"),
        ]
        for ruta in rutas_posibles:
            if os.path.exists(ruta):
                try:
                    pygame.mixer.music.load(ruta)
                    pygame.mixer.music.set_volume(self.volumen)
                    self._cargada = True
                    return
                except Exception:
                    pass
        # Si no se encontró el archivo, el juego funciona sin música
        self._cargada = False

    def reproducir(self):
        """Inicia la reproducción en bucle si está disponible y activa."""
        if self._cargada and self.activa:
            if not pygame.mixer.music.get_busy():
                pygame.mixer.music.play(-1)   # -1 = loop infinito

    def pausar(self):
        """Pausa la música sin resetear la posición."""
        if self._cargada and pygame.mixer.music.get_busy():
            pygame.mixer.music.pause()

    def reanudar(self):
        """Reanuda desde donde se pausó."""
        if self._cargada and self.activa:
            pygame.mixer.music.unpause()

    def detener(self):
        """Detiene la música completamente."""
        if self._cargada:
            pygame.mixer.music.stop()

    def toggle(self):
        """
        Alterna entre encendido y apagado.
        Retorna el nuevo estado (True = activa).
        """
        self.activa = not self.activa
        if self.activa:
            self.reproducir()
        else:
            self.detener()
        return self.activa

    def set_volumen(self, valor):
        """Ajusta el volumen (0.0 a 1.0)."""
        self.volumen = max(0.0, min(1.0, valor))
        if self._cargada:
            pygame.mixer.music.set_volume(self.volumen)

    @property
    def disponible(self):
        return self._cargada

"""
CLASH CHESS - Módulo del Juego
"""

import pygame
from tablero import Tablero
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA, TAMANO_CASILLA,
    MARGEN_IZQ, MARGEN_SUP,
    COLOR_FONDO_UI, COLOR_TEXTO, COLOR_TITULO,
    COLOR_BANNER_J1, COLOR_BANNER_J2, COLOR_BORDE,
    COLOR_BOTON, COLOR_BOTON_HOVER,
    JUGADOR_1, JUGADOR_2, NOMBRE_J1, NOMBRE_J2,
    pixel_a_fila_col, dibujar_boton, dibujar_boton_mixto, obtener_fuentes
)
from musica import GestorMusica


class Juego:
    """
    Clase principal de la partida.
    """

    def __init__(self, ventana, red=None, mi_jugador=None):
        self.ventana    = ventana
        self.fuentes    = obtener_fuentes()
        self.red        = red
        self.mi_jugador = mi_jugador
        self.musica     = GestorMusica()

        self._reiniciar()

    def _reiniciar(self):
        """
        Reinicia todos los datos de la partida.
        Se llama al iniciar o al jugar de nuevo.
        """
        self.tablero       = Tablero()
        self.turno_actual  = JUGADOR_1    # J1 siempre empieza
        self.pieza_selec   = None         # Ninguna pieza seleccionada
        self.movs_validos  = []           # Sin movimientos resaltados
        self.ganador       = None         # Aún sin ganador
        self.mensaje_turno = self._nombre_turno()

    #  BUCLE PRINCIPAL DE LA PANTALLA DE JUEGO

    def ejecutar(self):
        """
        Bucle de la pantalla de juego.
        """
        # Asegurar que la música siga sonando al entrar a la partida
        self.musica.reproducir()

        reloj = pygame.time.Clock()

        while True:
            # --- Gestión de eventos ---
            for evento in pygame.event.get():

                if evento.type == pygame.QUIT:
                    return "salir"

                if evento.type == pygame.KEYDOWN:
                    # ESC regresa al menú
                    if evento.key == pygame.K_ESCAPE:
                        return "menu"
                    # M alterna la música desde el juego
                    if evento.key == pygame.K_m:
                        self.musica.toggle()

                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if evento.button == 1:   # Click izquierdo
                        resultado = self._manejar_click(evento.pos)
                        if resultado:
                            return resultado

            if self.red is not None:
                self._procesar_movimiento_remoto()

            # --- Dibujo ---
            self._dibujar()
            pygame.display.flip()
            reloj.tick(60)

    #  MANEJO DE CLICKS DEL MOUSE

    def _manejar_click(self, pos):
        """
        Procesa un click del mouse según el estado actual.
        """
        # Si hay un ganador, manejar los botones de victoria
        if self.ganador:
            return self._click_pantalla_victoria(pos)

        if self.red is not None and self.turno_actual != self.mi_jugador:
            return None   # No es tu turno: ignorar click

        # Convertir pixel → casilla del tablero
        casilla = pixel_a_fila_col(pos[0], pos[1])

        if casilla is None:
            # Click fuera del tablero: deseleccionar
            self._deseleccionar()
            return None

        fila, col = casilla

        if self.pieza_selec is None:
            self._intentar_seleccionar(fila, col)
        else:
            if (fila, col) in self.movs_validos:
                self._ejecutar_movimiento(fila, col)
            elif self._es_pieza_propia(fila, col):
                self._intentar_seleccionar(fila, col)
            else:
                self._deseleccionar()

        return None

    def _intentar_seleccionar(self, fila, col):
        pieza = self.tablero.obtener_pieza(fila, col)
        if pieza and pieza.jugador == self.turno_actual:
            self.pieza_selec  = pieza
            self.movs_validos = pieza.obtener_movimientos(self.tablero)
        else:
            self._deseleccionar()

    def _deseleccionar(self):
        self.pieza_selec  = None
        self.movs_validos = []

    def _ejecutar_movimiento(self, nueva_fila, nueva_col):
        origen  = (self.pieza_selec.fila, self.pieza_selec.col)
        destino = (nueva_fila, nueva_col)

        if self.red is not None:
            self.red.enviar_movimiento(origen, destino)

        self.tablero.mover_pieza(self.pieza_selec, nueva_fila, nueva_col)
        self.ganador = self.tablero.verificar_victoria()
        self._deseleccionar()

        if not self.ganador:
            self._cambiar_turno()

    def _procesar_movimiento_remoto(self):
        if self.turno_actual == self.mi_jugador:
            return
        if not self.red.mensajes:
            return

        datos = self.red.mensajes.pop(0)
        if "origen" not in datos or "destino" not in datos:
            return

        fila_o, col_o = datos["origen"]
        fila_d, col_d = datos["destino"]
        pieza = self.tablero.obtener_pieza(fila_o, col_o)
        if pieza is None:
            return

        self.tablero.mover_pieza(pieza, fila_d, col_d)
        self.ganador = self.tablero.verificar_victoria()

        if not self.ganador:
            self._cambiar_turno()

    #  HELPERS DE TURNO

    def _cambiar_turno(self):
        self.turno_actual = (JUGADOR_2 if self.turno_actual == JUGADOR_1
                             else JUGADOR_1)
        self.mensaje_turno = self._nombre_turno()

    def _es_pieza_propia(self, fila, col):
        pieza = self.tablero.obtener_pieza(fila, col)
        return pieza is not None and pieza.jugador == self.turno_actual

    def _nombre_turno(self):
        return NOMBRE_J1 if self.turno_actual == JUGADOR_1 else NOMBRE_J2

    #  DIBUJO GENERAL

    def _dibujar(self):
        self.ventana.fill((20, 16, 30))
        self.tablero.dibujar(self.ventana, self.pieza_selec,
                             self.movs_validos)
        self._dibujar_panel_info()
        if self.ganador:
            self._dibujar_pantalla_victoria()

    def _dibujar_panel_info(self):
        """
        Dibuja el panel informativo a la derecha del tablero.
        """
        px = MARGEN_IZQ + 8 * TAMANO_CASILLA + 15
        py = MARGEN_SUP
        ancho_panel = ANCHO_VENTANA - px - 10
        alto_panel  = 8 * TAMANO_CASILLA

        panel_rect = pygame.Rect(px, py, ancho_panel, alto_panel)
        pygame.draw.rect(self.ventana, COLOR_FONDO_UI,
                         panel_rect, border_radius=10)
        pygame.draw.rect(self.ventana, COLOR_BORDE,
                         panel_rect, 2, border_radius=10)

        y = py + 10

        f_grande  = self.fuentes["grande"]
        f_normal  = self.fuentes["normal"]
        f_pequeña = self.fuentes["pequeña"]
        f_emoji   = self.fuentes["emoji_p"]

        # ── Indicador de turno ──────────────────────────────
        txt = f_grande.render("Turno", True, COLOR_TITULO)
        # Icono espada con fuente emoji
        r_ico = f_emoji.render("⚔", True, COLOR_TITULO)
        self.ventana.blit(r_ico, (px + 10, y + 2))
        self.ventana.blit(txt,   (px + 10 + r_ico.get_width() + 4, y))
        y += 38

        color_banner = (COLOR_BANNER_J1 if self.turno_actual == JUGADOR_1
                        else COLOR_BANNER_J2)
        banner_rect = pygame.Rect(px + 5, y, ancho_panel - 10, 36)
        pygame.draw.rect(self.ventana, color_banner,
                         banner_rect, border_radius=6)

        if self.red is not None:
            if self.turno_actual == self.mi_jugador:
                nombre = "Tu turno"
                ico    = "⬅"
            else:
                nombre = "Oponente..."
                ico    = "⏳"
            r_ico = f_emoji.render(ico, True, COLOR_TEXTO)
            r_txt = f_normal.render(nombre, True, COLOR_TEXTO)
            total_w = r_ico.get_width() + 4 + r_txt.get_width()
            bx = banner_rect.x + (banner_rect.width - total_w) // 2
            by_ico = y + (36 - r_ico.get_height()) // 2
            by_txt = y + (36 - r_txt.get_height()) // 2
            self.ventana.blit(r_ico, (bx, by_ico))
            self.ventana.blit(r_txt, (bx + r_ico.get_width() + 4, by_txt))
        else:
            nombre = self._nombre_turno()
            txt = f_normal.render(nombre, True, COLOR_TEXTO)
            tx = banner_rect.x + (banner_rect.width - txt.get_width()) // 2
            self.ventana.blit(txt, (tx, y + 7))
        y += 50

        # ── Piezas en juego ─────────────────────────────────
        txt = f_pequeña.render("Piezas en juego:", True, COLOR_TITULO)
        self.ventana.blit(txt, (px + 10, y))
        y += 22

        n1 = len(self.tablero.piezas_j1)
        n2 = len(self.tablero.piezas_j2)

        # Círculos de colores en vez de emojis para evitar cuadros
        pygame.draw.circle(self.ventana, (100, 160, 255), (px + 18, y + 8), 7)
        txt = f_pequeña.render(f" {NOMBRE_J1}: {n1}", True, (100, 160, 255))
        self.ventana.blit(txt, (px + 28, y))
        y += 20

        pygame.draw.circle(self.ventana, (255, 100, 100), (px + 18, y + 8), 7)
        txt = f_pequeña.render(f" {NOMBRE_J2}: {n2}", True, (255, 100, 100))
        self.ventana.blit(txt, (px + 28, y))
        y += 32

        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (px + 10, y), (px + ancho_panel - 10, y), 1)
        y += 10

        # ── Controles ───────────────────────────────────────
        txt = f_pequeña.render("Controles:", True, COLOR_TITULO)
        self.ventana.blit(txt, (px + 10, y))
        y += 20

        controles = [
            "Click  Seleccionar",
            "Click  Mover/Atacar",
            "ESC    Menu",
            "M      Musica on/off",
        ]
        for ctrl in controles:
            txt = f_pequeña.render(ctrl, True, COLOR_TEXTO)
            self.ventana.blit(txt, (px + 10, y))
            y += 17

        y += 8
        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (px + 10, y), (px + ancho_panel - 10, y), 1)
        y += 10

        # ── Leyenda con formas en vez de emojis ─────────────
        # Amarillo = seleccionada
        pygame.draw.rect(self.ventana, (255, 220, 0),
                         (px + 10, y + 2, 12, 12))
        txt = f_pequeña.render("  Seleccionada", True, COLOR_TEXTO)
        self.ventana.blit(txt, (px + 18, y))
        y += 17

        # Verde = movimiento
        pygame.draw.rect(self.ventana, (80, 200, 80),
                         (px + 10, y + 2, 12, 12))
        txt = f_pequeña.render("  Mov. valido", True, COLOR_TEXTO)
        self.ventana.blit(txt, (px + 18, y))
        y += 17

        # Rojo = ataque
        pygame.draw.rect(self.ventana, (220, 60, 60),
                         (px + 10, y + 2, 12, 12))
        txt = f_pequeña.render("  Ataque", True, COLOR_TEXTO)
        self.ventana.blit(txt, (px + 18, y))
        y += 22

        # ── Indicador de música ──────────────────────────────
        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (px + 10, y), (px + ancho_panel - 10, y), 1)
        y += 8
        estado_mus = "ON" if self.musica.activa else "OFF"
        color_mus  = (100, 220, 100) if self.musica.activa else (180, 100, 100)
        r_ico = f_emoji.render("🎵", True, color_mus)
        r_txt = f_pequeña.render(f" Musica: {estado_mus}", True, color_mus)
        self.ventana.blit(r_ico, (px + 10, y))
        self.ventana.blit(r_txt, (px + 10 + r_ico.get_width(), y + 2))

    #  PANTALLA DE VICTORIA

    def _dibujar_pantalla_victoria(self):
        """Muestra superposición con el ganador y botones de acción."""
        overlay = pygame.Surface((ANCHO_VENTANA, ALTO_VENTANA),
                                 pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        self.ventana.blit(overlay, (0, 0))

        cx = ANCHO_VENTANA // 2

        f_titulo  = self.fuentes["titulo"]
        f_grande  = self.fuentes["grande"]
        f_normal  = self.fuentes["normal"]
        f_emoji_g = self.fuentes["emoji_g"]

        # Trofeo con fuente emoji
        r_trofeo = f_emoji_g.render("🏆", True, COLOR_TITULO)
        r_vic    = f_titulo.render(" ¡VICTORIA!", True, COLOR_TITULO)
        total_w  = r_trofeo.get_width() + r_vic.get_width()
        self.ventana.blit(r_trofeo, (cx - total_w // 2, 200))
        self.ventana.blit(r_vic,    (cx - total_w // 2 + r_trofeo.get_width(), 200))

        nombre_ganador = NOMBRE_J1 if self.ganador == JUGADOR_1 else NOMBRE_J2
        txt = f_grande.render(f"{nombre_ganador} ha ganado", True, COLOR_TEXTO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 272))

        txt = f_normal.render("El Rey enemigo fue eliminado", True, (200, 200, 200))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 318))

        self.btn_reiniciar = pygame.Rect(cx - 130, 372, 260, 45)
        dibujar_boton(self.ventana, "Jugar de nuevo",
                      f_normal, self.btn_reiniciar,
                      (50, 120, 50), COLOR_TEXTO, (100, 200, 100))

        self.btn_menu_vic = pygame.Rect(cx - 130, 430, 260, 45)
        dibujar_boton(self.ventana, "Menu principal",
                      f_normal, self.btn_menu_vic,
                      COLOR_BOTON, COLOR_TEXTO, COLOR_BORDE)

    def _click_pantalla_victoria(self, pos):
        """Procesa clicks en los botones de la pantalla de victoria."""
        if hasattr(self, "btn_reiniciar") and self.btn_reiniciar.collidepoint(pos):
            self._reiniciar()
            return None

        if hasattr(self, "btn_menu_vic") and self.btn_menu_vic.collidepoint(pos):
            return "menu"

        return None

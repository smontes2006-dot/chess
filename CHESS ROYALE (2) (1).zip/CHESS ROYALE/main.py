"""
=============================================================
CLASH CHESS - Ajedrez Táctico Medieval
Segundo proyecto de Programación IS2026
Estudiantes: Keylor Lopez, Eyner Marin, Sebastian Montes
=============================================================
"""
import pygame
from menu import MenuPrincipal
from juego import Juego
from reglas import PantallaReglas
from multi import PantallaMulti
from utils import ANCHO_VENTANA, ALTO_VENTANA, FPS, TITULO_JUEGO
from red import Red


def main():
    """
    Función principal que inicializa el juego y gestiona
    la navegación entre pantallas mediante un estado global.
    """
    # Inicializar mixer ANTES de pygame.init() para mejor compatibilidad
    pygame.mixer.pre_init(44100, -16, 2, 512)
    pygame.init()
    pygame.mixer.init()

    pygame.display.set_caption(TITULO_JUEGO)
    ventana = pygame.display.set_mode((ANCHO_VENTANA, ALTO_VENTANA))
    reloj   = pygame.time.Clock()

    estado_actual = "menu"

    # Instancias de pantallas estáticas (se crean una sola vez)
    menu   = MenuPrincipal(ventana)
    juego  = Juego(ventana)
    reglas = PantallaReglas(ventana)
    multi  = PantallaMulti(ventana)

    while estado_actual != "salir":

        if estado_actual == "menu":
            estado_actual = menu.ejecutar()

        elif estado_actual == "juego":
            estado_actual = juego.ejecutar()

        elif estado_actual == "reglas":
            estado_actual = reglas.ejecutar()

        elif estado_actual == "multi":
            resultado = multi.ejecutar()
            # resultado es una tupla: (estado, red, mi_jugador)
            estado_sig, red_obj, mi_jugador = resultado

            if estado_sig == "juego_online":
                juego_online = Juego(ventana,
                                     red=red_obj,
                                     mi_jugador=mi_jugador)
                estado_actual = juego_online.ejecutar()
                multi = PantallaMulti(ventana)
            else:
                estado_actual = estado_sig

        reloj.tick(FPS)

    pygame.quit()


if __name__ == "__main__":
    main()

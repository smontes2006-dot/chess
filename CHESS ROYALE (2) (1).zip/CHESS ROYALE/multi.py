"""
CLASH CHESS - Pantalla de Configuración Multijugador
"""

import pygame
import threading
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA,
    COLOR_FONDO_MENU, COLOR_TITULO, COLOR_TEXTO,
    COLOR_BOTON, COLOR_BOTON_HOVER, COLOR_BORDE,
    COLOR_FONDO_UI,
    dibujar_boton, obtener_fuentes
)
from red import Red

JUGADOR_1 = 1
JUGADOR_2 = 2


class PantallaMulti:

    def __init__(self, ventana):
        self.ventana  = ventana
        self.fuentes  = obtener_fuentes()
        self.estado   = "inicio"

        self.ip_texto    = ""
        self.ip_activo   = False

        self.msg_estado  = ""

        self.red          = None
        self.num_jugador  = None
        self.conexion_ok  = False

        self.btn_servidor = None
        self.btn_cliente  = None
        self.btn_volver   = None
        self.btn_conectar = None
        self.campo_ip     = None

    def ejecutar(self):
        reloj = pygame.time.Clock()

        while True:
            mouse_pos = pygame.mouse.get_pos()

            for evento in pygame.event.get():

                if evento.type == pygame.QUIT:
                    return ("salir", None, None)

                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_ESCAPE:
                        return ("menu", None, None)

                    if self.estado == "cliente" and self.ip_activo:
                        if evento.key == pygame.K_BACKSPACE:
                            self.ip_texto = self.ip_texto[:-1]
                        elif evento.key == pygame.K_RETURN:
                            self._intentar_conectar_cliente()
                        elif len(self.ip_texto) < 15:
                            if evento.unicode in "0123456789.":
                                self.ip_texto += evento.unicode

                if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                    resultado = self._manejar_click(evento.pos)
                    if resultado:
                        return resultado

            if self.conexion_ok and self.red and self.num_jugador:
                return ("juego_online", self.red, self.num_jugador)

            self._dibujar(mouse_pos)
            pygame.display.flip()
            reloj.tick(60)

    def _manejar_click(self, pos):
        if self.estado == "inicio":
            if self.btn_servidor and self.btn_servidor.collidepoint(pos):
                self.estado     = "servidor"
                self.msg_estado = "Esperando al jugador 2..."
                threading.Thread(
                    target=self._arrancar_servidor, daemon=True
                ).start()
            elif self.btn_cliente and self.btn_cliente.collidepoint(pos):
                self.estado     = "cliente"
                self.msg_estado = "Ingresa la IP del servidor"
            elif self.btn_volver and self.btn_volver.collidepoint(pos):
                return ("menu", None, None)

        elif self.estado == "cliente":
            if self.campo_ip and self.campo_ip.collidepoint(pos):
                self.ip_activo = True
            elif self.btn_conectar and self.btn_conectar.collidepoint(pos):
                self._intentar_conectar_cliente()
            elif self.btn_volver and self.btn_volver.collidepoint(pos):
                self.estado     = "inicio"
                self.ip_texto   = ""
                self.ip_activo  = False
                self.msg_estado = ""
            else:
                self.ip_activo = False

        elif self.estado == "error":
            if self.btn_volver and self.btn_volver.collidepoint(pos):
                self.estado     = "inicio"
                self.msg_estado = ""

        return None

    # ── LÓGICA DE CONEXIÓN ───────────────────────────────────────

    def _arrancar_servidor(self):
        try:
            red = Red()
            red.iniciar_servidor(puerto=5555)
            self.red         = red
            self.num_jugador = JUGADOR_1
            self.conexion_ok = True
            self.msg_estado  = "Jugador 2 conectado! Iniciando..."
        except Exception as e:
            self.estado     = "error"
            self.msg_estado = f"Error al abrir servidor: {e}"

    def _intentar_conectar_cliente(self):
        ip = self.ip_texto.strip()
        if not ip:
            self.msg_estado = "Escribe la IP primero"
            return
        self.estado     = "conectando"
        self.msg_estado = f"Conectando a {ip}..."
        threading.Thread(
            target=self._conectar_cliente, args=(ip,), daemon=True
        ).start()

    def _conectar_cliente(self, ip):
        try:
            red = Red()
            red.conectar(ip, puerto=5555)
            self.red         = red
            self.num_jugador = JUGADOR_2
            self.conexion_ok = True
            self.msg_estado  = "Conectado! Iniciando partida..."
        except Exception as e:
            self.estado     = "error"
            self.msg_estado = f"No se pudo conectar: {e}"

    # ── DIBUJO ───────────────────────────────────────────────────

    def _dibujar(self, mouse_pos):
        self.ventana.fill(COLOR_FONDO_MENU)

        cx        = ANCHO_VENTANA // 2
        f_titulo  = self.fuentes["titulo"]
        f_grande  = self.fuentes["grande"]
        f_normal  = self.fuentes["normal"]
        f_pequeña = self.fuentes["pequeña"]
        f_emoji_g = self.fuentes["emoji_g"]

        # Título con emoji separado
        r_ico = f_emoji_g.render("🌐", True, COLOR_TITULO)
        r_tit = f_titulo.render("  MODO ONLINE", True, COLOR_TITULO)
        total_w = r_ico.get_width() + r_tit.get_width()
        self.ventana.blit(r_ico, (cx - total_w // 2, 80))
        self.ventana.blit(r_tit, (cx - total_w // 2 + r_ico.get_width(), 80))

        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (cx - 200, 142), (cx + 200, 142), 2)

        if self.estado == "inicio":
            self._dibujar_inicio(mouse_pos, cx, f_grande, f_normal, f_pequeña)
        elif self.estado in ("servidor", "conectando"):
            self._dibujar_esperando(cx, f_grande, f_normal, f_pequeña)
        elif self.estado == "cliente":
            self._dibujar_cliente(mouse_pos, cx, f_grande, f_normal, f_pequeña)
        elif self.estado == "error":
            self._dibujar_error(mouse_pos, cx, f_grande, f_normal)

        if self.msg_estado:
            txt = f_pequeña.render(self.msg_estado, True, (200, 200, 140))
            self.ventana.blit(txt, (cx - txt.get_width() // 2, ALTO_VENTANA - 60))

    def _boton_con_emoji(self, superficie, emoji, texto,
                          f_emoji, f_texto, rect,
                          color_fondo, mouse_pos):
        """Dibuja un botón con emoji real + texto, con efecto hover."""
        hover = rect.collidepoint(mouse_pos)
        color = COLOR_BOTON_HOVER if hover else color_fondo

        pygame.draw.rect(superficie, color, rect, border_radius=8)
        pygame.draw.rect(superficie, COLOR_BORDE, rect, 2, border_radius=8)

        r_e = f_emoji.render(emoji, True, COLOR_TEXTO)
        r_t = f_texto.render(texto, True, COLOR_TEXTO)
        total_w = r_e.get_width() + 4 + r_t.get_width()
        bx = rect.x + (rect.width - total_w) // 2
        by_e = rect.y + (rect.height - r_e.get_height()) // 2
        by_t = rect.y + (rect.height - r_t.get_height()) // 2
        superficie.blit(r_e, (bx, by_e))
        superficie.blit(r_t, (bx + r_e.get_width() + 4, by_t))

    def _dibujar_inicio(self, mouse_pos, cx, f_grande, f_normal, f_pequeña):
        f_emoji = self.fuentes["emoji_p"]
        ancho, alto = 290, 55

        # Botón Crear partida (Servidor / J1)
        self.btn_servidor = pygame.Rect(cx - ancho // 2, 200, ancho, alto)
        self._boton_con_emoji(self.ventana, "🖥", "  CREAR PARTIDA (J1)",
                               f_emoji, f_normal,
                               self.btn_servidor, COLOR_BOTON, mouse_pos)

        txt = f_pequeña.render("Abre un servidor  ·  Eres el Jugador 1 (Azul)",
                               True, (160, 160, 160))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 262))

        # Botón Unirse (Cliente / J2)
        self.btn_cliente = pygame.Rect(cx - ancho // 2, 295, ancho, alto)
        self._boton_con_emoji(self.ventana, "🔌", "  UNIRSE A PARTIDA (J2)",
                               f_emoji, f_normal,
                               self.btn_cliente, COLOR_BOTON, mouse_pos)

        txt = f_pequeña.render("Ingresa la IP del servidor  ·  Eres Jugador 2 (Rojo)",
                               True, (160, 160, 160))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 357))

        # Botón Volver
        self.btn_volver = pygame.Rect(cx - 120, 410, 240, 44)
        self._boton_con_emoji(self.ventana, "←", " Volver",
                               f_emoji, f_normal,
                               self.btn_volver, COLOR_BOTON, mouse_pos)

    def _dibujar_esperando(self, cx, f_grande, f_normal, f_pequeña):
        f_emoji = self.fuentes["emoji_g"]

        r_e = f_emoji.render("⏳", True, COLOR_TITULO)
        r_t = f_grande.render("  Esperando conexion...", True, COLOR_TITULO)
        total_w = r_e.get_width() + r_t.get_width()
        self.ventana.blit(r_e, (cx - total_w // 2, 240))
        self.ventana.blit(r_t, (cx - total_w // 2 + r_e.get_width(), 248))

        txt = f_normal.render("Comparte tu IP local con el otro jugador",
                              True, COLOR_TEXTO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 300))

        txt = f_pequeña.render(
            "Tip: en Windows usa 'ipconfig', en Mac/Linux usa 'ifconfig'",
            True, (150, 150, 150))
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 340))

        self.btn_volver = None

    def _dibujar_cliente(self, mouse_pos, cx, f_grande, f_normal, f_pequeña):
        f_emoji = self.fuentes["emoji_p"]

        txt = f_grande.render("Ingresa la IP del servidor:", True, COLOR_TITULO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 190))

        self.campo_ip = pygame.Rect(cx - 150, 250, 300, 44)
        color_campo = (80, 70, 110) if self.ip_activo else COLOR_FONDO_UI
        pygame.draw.rect(self.ventana, color_campo,
                         self.campo_ip, border_radius=8)
        pygame.draw.rect(self.ventana, COLOR_BORDE,
                         self.campo_ip, 2, border_radius=8)

        display_ip = self.ip_texto + ("|" if self.ip_activo else "")
        txt = f_normal.render(display_ip or "Ej: 192.168.1.5",
                              True,
                              COLOR_TEXTO if self.ip_texto else (100, 100, 100))
        self.ventana.blit(txt, (self.campo_ip.x + 10, self.campo_ip.y + 10))

        self.btn_conectar = pygame.Rect(cx - 120, 318, 240, 46)
        self._boton_con_emoji(self.ventana, "🔌", "  Conectar",
                               f_emoji, f_normal,
                               self.btn_conectar, COLOR_BOTON, mouse_pos)

        self.btn_volver = pygame.Rect(cx - 120, 385, 240, 44)
        self._boton_con_emoji(self.ventana, "←", " Volver",
                               f_emoji, f_normal,
                               self.btn_volver, COLOR_BOTON, mouse_pos)

    def _dibujar_error(self, mouse_pos, cx, f_grande, f_normal):
        f_emoji = self.fuentes["emoji_g"]

        r_e = f_emoji.render("❌", True, (255, 80, 80))
        r_t = f_grande.render("  Error de conexion", True, (255, 80, 80))
        total_w = r_e.get_width() + r_t.get_width()
        self.ventana.blit(r_e, (cx - total_w // 2, 230))
        self.ventana.blit(r_t, (cx - total_w // 2 + r_e.get_width(), 236))

        self.btn_volver = pygame.Rect(cx - 130, 320, 260, 46)
        self._boton_con_emoji(self.ventana, "🔄", "  Reintentar",
                               self.fuentes["emoji_p"], f_normal,
                               self.btn_volver, COLOR_BOTON, mouse_pos)

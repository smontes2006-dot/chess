"""
CLASH CHESS - Menú Principal
"""

import pygame
import math
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA,
    COLOR_FONDO_MENU, COLOR_TITULO, COLOR_TEXTO,
    COLOR_BOTON, COLOR_BOTON_HOVER, COLOR_BORDE,
    dibujar_boton, dibujar_boton_mixto, obtener_fuentes
)
from musica import GestorMusica


class MenuPrincipal:
    """
    Pantalla del menú principal del juego.
    """

    def __init__(self, ventana):
        self.ventana = ventana
        self.fuentes = obtener_fuentes()
        self.tiempo  = 0   # Contador de frames para animaciones
        self.musica  = GestorMusica()
        # Iniciar música al entrar al menú
        self.musica.reproducir()

    #  BUCLE PRINCIPAL DEL MENÚ

    def ejecutar(self):
        """
        Bucle de la pantalla del menú. Espera input del usuario.
        """
        reloj = pygame.time.Clock()

        while True:
            self.tiempo += 1
            mouse_pos = pygame.mouse.get_pos()

            # --- Gestión de eventos ---
            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    return "salir"

                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if evento.button == 1:
                        resultado = self._verificar_click(evento.pos)
                        if resultado:
                            return resultado

            # --- Dibujo ---
            self._dibujar(mouse_pos)
            pygame.display.flip()
            reloj.tick(60)

    #  VERIFICACIÓN DE CLICKS

    def _verificar_click(self, pos):

        if self.btn_jugar.collidepoint(pos):
            return "juego"

        if self.btn_multi.collidepoint(pos):
            return "multi"

        if self.btn_reglas.collidepoint(pos):
            return "reglas"

        if self.btn_salir.collidepoint(pos):
            return "salir"

        # Botón de música (toggle)
        if self.btn_musica.collidepoint(pos):
            self.musica.toggle()
            return None   # No cambiar de pantalla

        return None

    #  DIBUJO DEL MENÚ

    def _dibujar(self, mouse_pos):
        """Renderiza todos los elementos del menú."""
        self.ventana.fill(COLOR_FONDO_MENU)
        self._dibujar_fondo_decorativo()
        self._dibujar_titulo()
        self._dibujar_botones(mouse_pos)
        self._dibujar_boton_musica(mouse_pos)
        self._dibujar_pie()

    def _dibujar_fondo_decorativo(self):
        """
        Dibuja elementos decorativos de fondo: círculos tenues
        que oscilan con el tiempo para dar sensación de vida.
        """
        for i in range(5):
            pulso = math.sin(self.tiempo * 0.02 + i * 1.2)
            radio = int(40 + 15 * pulso + i * 30)
            alpha = max(10, int(25 + 10 * pulso))

            circ = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
            pygame.draw.circle(circ, (100, 70, 150, alpha),
                               (radio, radio), radio)

            cx = [150, 750, 450, 80, 820][i]
            cy = [150, 100, 500, 550, 450][i]
            self.ventana.blit(circ, (cx - radio, cy - radio))

    def _dibujar_titulo(self):
        """Dibuja el título principal y el subtítulo del juego."""
        f_titulo  = self.fuentes["titulo"]
        f_normal  = self.fuentes["normal"]
        f_emoji_g = self.fuentes["emoji_g"]
        cx = ANCHO_VENTANA // 2

        # Icono decorativo superior — renderizado con fuente emoji correcta
        iconos = "⚔️  👑  🏰"
        txt = f_emoji_g.render(iconos, True, COLOR_TITULO)
        self.ventana.blit(txt, (cx - txt.get_width() // 2, 100))

        # Título principal
        titulo = "CLASH  CHESS"
        txt_titulo = f_titulo.render(titulo, True, COLOR_TITULO)
        self.ventana.blit(txt_titulo, (cx - txt_titulo.get_width() // 2, 148))

        # Línea dorada decorativa
        largo = 300
        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (cx - largo // 2, 210), (cx + largo // 2, 210), 2)

        # Subtítulo
        sub = "Ajedrez Táctico Clash Royale"
        txt_sub = f_normal.render(sub, True, (200, 180, 140))
        self.ventana.blit(txt_sub, (cx - txt_sub.get_width() // 2, 218))

    def _dibujar_botones(self, mouse_pos):
        """
        Dibuja los botones del menú con efecto hover.
        Usa fuente emoji separada para evitar cuadros.
        """
        cx       = ANCHO_VENTANA // 2
        f_grande = self.fuentes["grande"]
        f_emoji  = self.fuentes["emoji"]

        ancho_btn = 280
        alto_btn  = 52
        x_btn     = cx - ancho_btn // 2

        # ── Botones: (emoji, etiqueta, y, clave) ──────────────
        # Posiciones corregidas: sin hueco extra entre JUGAR y ONLINE
        botones_info = [
            ("⚔",  "  JUGAR",   258, "jugar"),
            ("🌐", "  ONLINE",  320, "multi"),
            ("📖", "  REGLAS",  382, "reglas"),
            ("🚪", "  SALIR",   444, "salir"),
        ]

        for emoji, etiqueta, y, clave in botones_info:
            rect  = pygame.Rect(x_btn, y, ancho_btn, alto_btn)
            hover = rect.collidepoint(mouse_pos)
            color_fondo = COLOR_BOTON_HOVER if hover else COLOR_BOTON

            # Dibujar con emoji separado para correcta renderización
            dibujar_boton_mixto(
                self.ventana,
                emoji, etiqueta,
                f_emoji, f_grande,
                rect, color_fondo, COLOR_TEXTO,
                COLOR_BORDE, radio=10
            )

            # Guardar referencias
            if clave == "jugar":
                self.btn_jugar = rect
            elif clave == "multi":
                self.btn_multi = rect
            elif clave == "reglas":
                self.btn_reglas = rect
            elif clave == "salir":
                self.btn_salir = rect

    def _dibujar_boton_musica(self, mouse_pos):
        """
        Dibuja el botón de toggle de música en la esquina
        inferior derecha.
        """
        f_emoji  = self.fuentes["emoji_p"]
        f_pequeña = self.fuentes["pequeña"]

        # Posición: esquina inferior derecha
        ancho = 140
        alto  = 34
        x = ANCHO_VENTANA - ancho - 15
        y = ALTO_VENTANA  - alto  - 12

        self.btn_musica = pygame.Rect(x, y, ancho, alto)
        hover = self.btn_musica.collidepoint(mouse_pos)
        color = COLOR_BOTON_HOVER if hover else COLOR_BOTON

        if self.musica.activa:
            emoji, label = "🎵", " Música: ON"
        else:
            emoji, label = "🔇", " Música: OFF"

        # Fondo del botón
        pygame.draw.rect(self.ventana, color,
                         self.btn_musica, border_radius=8)
        pygame.draw.rect(self.ventana, COLOR_BORDE,
                         self.btn_musica, 1, border_radius=8)

        # Emoji + texto
        r_emoji = f_emoji.render(emoji, True, COLOR_TEXTO)
        r_texto = f_pequeña.render(label, True, COLOR_TEXTO)
        total_w = r_emoji.get_width() + r_texto.get_width()
        cx_btn  = x + (ancho - total_w) // 2
        cy_emoji = y + (alto - r_emoji.get_height()) // 2
        cy_texto = y + (alto - r_texto.get_height()) // 2
        self.ventana.blit(r_emoji, (cx_btn, cy_emoji))
        self.ventana.blit(r_texto, (cx_btn + r_emoji.get_width(), cy_texto))

    def _dibujar_pie(self):
        """Dibuja una nota pequeña al pie de la pantalla."""
        f_pequeña = self.fuentes["pequeña"]
        txt = f_pequeña.render(
            "La clave de la victoria es analizar los movimientos del rival",
            True, (100, 90, 120)
        )
        cx = ANCHO_VENTANA // 2
        self.ventana.blit(txt,
                          (cx - txt.get_width() // 2, ALTO_VENTANA - 30))

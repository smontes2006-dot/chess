"""
CLASH CHESS - Pantalla de Reglas 
"""

import pygame
from utils import (
    ANCHO_VENTANA, ALTO_VENTANA,
    COLOR_FONDO_MENU, COLOR_TITULO, COLOR_TEXTO,
    COLOR_BOTON, COLOR_BORDE, COLOR_BOTON_HOVER,
    dibujar_boton, dibujar_texto_centrado, obtener_fuentes
)


class PantallaReglas:

    def __init__(self, ventana):
        self.ventana  = ventana
        self.fuentes  = obtener_fuentes()
        self.scroll_y = 0

        self.contenido = self._construir_contenido()

    def _construir_contenido(self):
        # Separamos emoji del texto para renderizarlos con fuentes distintas
        # Formato: (tipo, emoji_o_None, texto)
        return [
            ("titulo",  "📜", " FICHA TECNICA - CLASH CHESS"),
            ("espacio", None, ""),
            ("texto",   None, "Juego de estrategia por turnos para 2 jugadores."),
            ("texto",   None, "Inspirado en el ajedrez clasico con tematica de Clash Royale."),
            ("espacio", None, ""),
            ("sep",     None, ""),

            ("titulo",  "🎯", " OBJETIVO"),
            ("espacio", None, ""),
            ("texto",   None, "Capturar el REY del jugador contrario para ganar la partida."),
            ("texto",   None, "No hay jaque mate: el Rey simplemente debe ser eliminado."),
            ("espacio", None, ""),
            ("sep",     None, ""),

            ("titulo",  "🕹", " COMO JUGAR"),
            ("espacio", None, ""),
            ("texto",   None, "1. El Jugador 1 (Azul) siempre empieza primero."),
            ("texto",   None, "2. Haz click en una de tus piezas para seleccionarla."),
            ("texto",   None, "3. Las casillas verdes indican donde puedes moverte."),
            ("texto",   None, "4. Las casillas rojas indican piezas enemigas que puedes atacar."),
            ("texto",   None, "5. Haz click en el destino para ejecutar el movimiento."),
            ("texto",   None, "6. Los turnos se alternan hasta que un Rey sea capturado."),
            ("espacio", None, ""),
            ("sep",     None, ""),

            ("titulo",  "♟", "  PIEZAS Y MOVIMIENTOS"),
            ("espacio", None, ""),

            ("subtit",  "👑", "  REY"),
            ("texto",   None, "Se mueve 1 casilla en cualquier direccion (8 posibles)."),
            ("texto",   None, "Si tu Rey es capturado, pierdes la partida."),
            ("espacio", None, ""),

            ("subtit",  "🗿", "  GIGANTE  (Torre medieval)"),
            ("texto",   None, "Se mueve multiples casillas: adelante, izquierda o derecha."),
            ("texto",   None, "No se mueve en diagonal. Se detiene ante piezas propias."),
            ("texto",   None, "Puede capturar la primera pieza enemiga que encuentre."),
            ("espacio", None, ""),

            ("subtit",  "🏹", "  PRINCESA  (Arquera a distancia)"),
            ("texto",   None, "Se mueve 1 casilla en cualquier direccion (solo casillas vacias)."),
            ("texto",   None, "Puede ATACAR a distancia hasta 3 casillas al frente en linea recta."),
            ("texto",   None, "El ataque se detiene al impactar con la primera pieza enemiga."),
            ("espacio", None, ""),

            ("subtit",  "🧙", "  MAGO  (Control diagonal)"),
            ("texto",   None, "Se mueve hasta 2 casillas en diagonal y 2 hacia adelante."),
            ("texto",   None, "Puede capturar piezas enemigas en esas diagonales."),
            ("texto",   None, "Su movimiento se bloquea si hay piezas propias en el camino."),
            ("espacio", None, ""),

            ("subtit",  "👺", "  DUENDE  (Unidad basica)"),
            ("texto",   None, "Avanza 1 casilla hacia adelante y hacia los lados."),
            ("texto",   None, "Si hay un enemigo directamente al frente, puede atacarlo."),
            ("texto",   None, "Es la unidad mas simple pero util para bloquear y presionar."),
            ("espacio", None, ""),
            ("sep",     None, ""),

            ("titulo",  "⌨", "  CONTROLES"),
            ("espacio", None, ""),
            ("texto",   None, "Click izquierdo    -> Seleccionar pieza / Confirmar movimiento"),
            ("texto",   None, "Click en otra pieza propia -> Cambiar seleccion"),
            ("texto",   None, "ESC                -> Volver al menu principal"),
            ("texto",   None, "M                  -> Activar/desactivar musica"),
            ("texto",   None, "Scroll arriba/abajo -> Desplazar esta pantalla"),
            ("espacio", None, ""),
            ("sep",     None, ""),

            ("titulo",  "🎓", "  FICHA DEL PROYECTO"),
            ("espacio", None, ""),
            ("texto",   None, "Nombre     : Clash Chess - Ajedrez Tactico Medieval"),
            ("texto",   None, "Lenguaje   : Python 3"),
            ("texto",   None, "Libreria   : Pygame"),
            ("texto",   None, "Modalidad  : 1v1 Local / Online"),
            ("texto",   None, "Tablero    : 8x8 casillas"),
            ("texto",   None, "Turnos     : Por turno (no tiempo real)"),
            ("espacio", None, ""),
        ]

    def ejecutar(self):
        reloj = pygame.time.Clock()

        while True:
            mouse_pos = pygame.mouse.get_pos()

            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    return "salir"

                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_ESCAPE:
                        return "menu"
                    if evento.key == pygame.K_DOWN:
                        self.scroll_y = min(self.scroll_y + 20, self._max_scroll())
                    if evento.key == pygame.K_UP:
                        self.scroll_y = max(self.scroll_y - 20, 0)

                if evento.type == pygame.MOUSEWHEEL:
                    self.scroll_y -= evento.y * 20
                    self.scroll_y = max(0, min(self.scroll_y, self._max_scroll()))

                if evento.type == pygame.MOUSEBUTTONDOWN:
                    if evento.button == 1:
                        if self.btn_volver.collidepoint(evento.pos):
                            return "menu"

            self._dibujar(mouse_pos)
            pygame.display.flip()
            reloj.tick(60)

    def _dibujar(self, mouse_pos):
        self.ventana.fill(COLOR_FONDO_MENU)
        self._dibujar_contenido()
        self._dibujar_boton_volver(mouse_pos)

    def _dibujar_contenido(self):
        f_titulo  = self.fuentes["grande"]
        f_subtit  = self.fuentes["normal"]
        f_texto   = self.fuentes["pequeña"]
        f_emoji_g = self.fuentes["emoji_g"]   # Para títulos
        f_emoji_p = self.fuentes["emoji_p"]   # Para subtítulos

        x_margen = 60
        y        = 30 - self.scroll_y
        alto_visible = ALTO_VENTANA - 80

        for tipo, emoji, texto in self.contenido:

            if y > alto_visible:
                break
            if y < -40:
                y += self._altura_linea(tipo)
                continue

            if tipo == "titulo":
                if y > 0:
                    # Renderizar emoji con fuente emoji + texto con Georgia
                    if emoji:
                        r_e = f_emoji_g.render(emoji, True, COLOR_TITULO)
                        r_t = f_titulo.render(texto, True, COLOR_TITULO)
                        self.ventana.blit(r_e, (x_margen, y - 2))
                        self.ventana.blit(r_t, (x_margen + r_e.get_width() + 2, y))
                    else:
                        r_t = f_titulo.render(texto, True, COLOR_TITULO)
                        self.ventana.blit(r_t, (x_margen, y))
                y += 40

            elif tipo == "subtit":
                if y > 0:
                    color_sub = (220, 200, 255)
                    if emoji:
                        r_e = f_emoji_p.render(emoji, True, color_sub)
                        r_t = f_subtit.render(texto, True, color_sub)
                        self.ventana.blit(r_e, (x_margen + 10, y - 1))
                        self.ventana.blit(r_t, (x_margen + 10 + r_e.get_width() + 2, y))
                    else:
                        r_t = f_subtit.render(texto, True, color_sub)
                        self.ventana.blit(r_t, (x_margen + 10, y))
                y += 28

            elif tipo == "texto":
                if y > 0:
                    txt = f_texto.render(texto, True, COLOR_TEXTO)
                    self.ventana.blit(txt, (x_margen + 20, y))
                y += 22

            elif tipo == "espacio":
                y += 10

            elif tipo == "sep":
                if y > 0:
                    pygame.draw.line(
                        self.ventana, COLOR_BORDE,
                        (x_margen, y + 5),
                        (ANCHO_VENTANA - x_margen, y + 5), 1
                    )
                y += 20

        self._altura_total = y + self.scroll_y

    def _altura_linea(self, tipo):
        alturas = {
            "titulo" : 40,
            "subtit" : 28,
            "texto"  : 22,
            "espacio": 10,
            "sep"    : 20,
        }
        return alturas.get(tipo, 22)

    def _max_scroll(self):
        return max(0, getattr(self, "_altura_total", 0) - ALTO_VENTANA + 100)

    def _dibujar_boton_volver(self, mouse_pos):
        f_normal  = self.fuentes["normal"]
        f_emoji_p = self.fuentes["emoji_p"]

        self.btn_volver = pygame.Rect(
            ANCHO_VENTANA // 2 - 120,
            ALTO_VENTANA - 60,
            240, 44
        )

        hover = self.btn_volver.collidepoint(mouse_pos)
        color = (70, 55, 100) if hover else COLOR_BOTON

        bg = pygame.Rect(0, ALTO_VENTANA - 75, ANCHO_VENTANA, 75)
        pygame.draw.rect(self.ventana, COLOR_FONDO_MENU, bg)
        pygame.draw.line(self.ventana, COLOR_BORDE,
                         (0, ALTO_VENTANA - 75),
                         (ANCHO_VENTANA, ALTO_VENTANA - 75), 1)

        # Botón sin emoji para evitar cuadros
        pygame.draw.rect(self.ventana, color,
                         self.btn_volver, border_radius=8)
        pygame.draw.rect(self.ventana, COLOR_BORDE,
                         self.btn_volver, 2, border_radius=8)

        # Flecha con emoji + texto separados
        r_e = f_emoji_p.render("←", True, COLOR_TEXTO)
        r_t = f_normal.render(" Volver al Menu", True, COLOR_TEXTO)
        total_w = r_e.get_width() + r_t.get_width()
        bx = self.btn_volver.x + (self.btn_volver.width - total_w) // 2
        by_e = self.btn_volver.y + (self.btn_volver.height - r_e.get_height()) // 2
        by_t = self.btn_volver.y + (self.btn_volver.height - r_t.get_height()) // 2
        self.ventana.blit(r_e, (bx, by_e))
        self.ventana.blit(r_t, (bx + r_e.get_width(), by_t))

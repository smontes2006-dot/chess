"""
CLASH CHESS - Utilidades y Constantes Globales
"""

import pygame
import sys

#  CONFIGURACIÓN DE VENTANA

ANCHO_VENTANA = 900          # Ancho total de la ventana en píxeles
ALTO_VENTANA  = 700          # Alto total de la ventana en píxeles
FPS           = 60           # Fotogramas por segundo
TITULO_JUEGO  = "Clash Chess - Ajedrez Táctico Medieval"
#  CONFIGURACIÓN DEL TABLERO
FILAS         = 8            # Número de filas del tablero
COLUMNAS      = 8            # Número de columnas del tablero
MARGEN_IZQ    = 100          # Espacio a la izquierda del tablero (px)
MARGEN_SUP    = 60           # Espacio arriba del tablero (px)
TAMANO_CASILLA = 70          # Tamaño de cada casilla en píxeles

# Dimensiones totales del tablero (calculadas automáticamente)
ANCHO_TABLERO = COLUMNAS * TAMANO_CASILLA   # 560 px
ALTO_TABLERO  = FILAS    * TAMANO_CASILLA   # 560 px

#  PALETA DE COLORES  

# Colores del tablero
COLOR_CASILLA_CLARA  = (240, 217, 181)   # Beige arena
COLOR_CASILLA_OSCURA = (181, 136, 99)    # Marrón madera

# Colores de jugadores
COLOR_JUGADOR_1 = (70,  130, 220)        # Azul real (jugador 1)
COLOR_JUGADOR_2 = (220,  70,  70)        # Rojo carmesí (jugador 2)

# Resaltados y selección
COLOR_SELECCION    = (255, 255,   0, 160)  # Amarillo semitransparente
COLOR_MOVIMIENTO   = (100, 220, 100, 140)  # Verde semitransparente
COLOR_ATAQUE       = (220,  60,  60, 160)  # Rojo semitransparente

# Colores de interfaz
COLOR_FONDO_MENU   = (20,  16,  30)       # Morado oscuro / noche medieval
COLOR_FONDO_UI     = (30,  25,  40)       # Panel lateral oscuro
COLOR_TEXTO        = (255, 240, 210)      # Crema cálido
COLOR_TITULO       = (255, 200,  50)      # Dorado
COLOR_BOTON        = (60,  45,  80)       # Morado medio
COLOR_BOTON_HOVER  = (90,  70, 120)       # Morado claro al pasar mouse
COLOR_BORDE        = (180, 140,  60)      # Dorado oscuro para bordes
COLOR_BANNER_J1    = ( 40,  80, 160)      # Fondo banner jugador 1
COLOR_BANNER_J2    = (160,  40,  40)      # Fondo banner jugador 2

# Colores de piezas (fill)
COLOR_PIEZA_J1     = ( 80, 150, 240)      # Azul claro jugador 1
COLOR_PIEZA_J2     = (240,  80,  80)      # Rojo claro jugador 2
COLOR_PIEZA_BORDE  = ( 10,  10,  10)      # Borde negro de piezas


#  NOMBRES DE JUGADORES

NOMBRE_J1 = "Jugador 1"
NOMBRE_J2 = "Jugador 2"


#  IDENTIFICADORES DE JUGADOR

JUGADOR_1 = 1
JUGADOR_2 = 2


def _buscar_fuente_emoji():
    """
    Busca la mejor fuente disponible en el sistema para renderizar emojis.
    Retorna el nombre de la fuente encontrada.
    """
    candidatas = [
        "Segoe UI Emoji",       # Windows
        "Apple Color Emoji",    # macOS
        "Noto Color Emoji",     # Linux (Google)
        "Noto Emoji",           # Linux alternativa
        "Twitter Color Emoji",  # Alternativa cross-platform
        "EmojiOne Color",       # Linux
        "Symbola",              # Fuente unicode genérica
        "Segoe UI Symbol",      # Windows fallback
        "Arial Unicode MS",     # macOS/Windows fallback
    ]
    disponibles = [f.lower() for f in pygame.font.get_fonts()]
    for nombre in candidatas:
        if nombre.lower().replace(" ", "") in [f.replace(" ", "") for f in disponibles]:
            return nombre
    # Último recurso: fuente por defecto del sistema
    return None


# Variable global con la mejor fuente emoji encontrada
_FUENTE_EMOJI_NOMBRE = None  # Se inicializa en obtener_fuentes()


def obtener_fuentes():
    global _FUENTE_EMOJI_NOMBRE

    # Detectar la mejor fuente emoji disponible
    _FUENTE_EMOJI_NOMBRE = _buscar_fuente_emoji()
    fuente_emoji = _FUENTE_EMOJI_NOMBRE if _FUENTE_EMOJI_NOMBRE else "Arial"

    return {
        "titulo"  : pygame.font.SysFont("Georgia",     48, bold=True),
        "grande"  : pygame.font.SysFont("Georgia",     32, bold=True),
        "normal"  : pygame.font.SysFont("Georgia",     22),
        "pequeña" : pygame.font.SysFont("Georgia",     16),
        "pieza"   : pygame.font.SysFont("Segoe UI",    18, bold=True),
        # Fuentes emoji en distintos tamaños
        "emoji"   : pygame.font.SysFont(fuente_emoji,  28),
        "emoji_g" : pygame.font.SysFont(fuente_emoji,  36),
        "emoji_p" : pygame.font.SysFont(fuente_emoji,  18),
    }


def dibujar_texto_centrado(superficie, texto, fuente, color, y):

    render = fuente.render(texto, True, color)
    x = (superficie.get_width() - render.get_width()) // 2
    superficie.blit(render, (x, y))


def dibujar_boton(superficie, texto, fuente, rect, color_fondo,
                  color_texto, color_borde=None, radio=8):
    """
    Dibuja un botón rectangular con bordes redondeados.
    """
    # Fondo del botón
    pygame.draw.rect(superficie, color_fondo, rect, border_radius=radio)

    # Borde opcional
    if color_borde:
        pygame.draw.rect(superficie, color_borde, rect,
                         width=2, border_radius=radio)

    # Texto centrado en el botón
    render = fuente.render(texto, True, color_texto)
    tx = rect.x + (rect.width  - render.get_width())  // 2
    ty = rect.y + (rect.height - render.get_height()) // 2
    superficie.blit(render, (tx, ty))

    return rect


def dibujar_boton_mixto(superficie, emoji, texto, fuente_emoji, fuente_texto,
                         rect, color_fondo, color_texto, color_borde=None, radio=8):
    """
    Dibuja un botón con emoji (fuente emoji) + texto (fuente normal) lado a lado.
    Evita el problema de cuadros cuando Georgia intenta renderizar emojis.
    """
    pygame.draw.rect(superficie, color_fondo, rect, border_radius=radio)
    if color_borde:
        pygame.draw.rect(superficie, color_borde, rect, width=2, border_radius=radio)

    render_emoji = fuente_emoji.render(emoji, True, color_texto)
    render_texto = fuente_texto.render(texto, True, color_texto)

    total_w = render_emoji.get_width() + 6 + render_texto.get_width()
    cx = rect.x + (rect.width - total_w) // 2
    cy_emoji = rect.y + (rect.height - render_emoji.get_height()) // 2
    cy_texto = rect.y + (rect.height - render_texto.get_height()) // 2

    superficie.blit(render_emoji, (cx, cy_emoji))
    superficie.blit(render_texto, (cx + render_emoji.get_width() + 6, cy_texto))

    return rect


def fila_col_a_pixel(fila, col):
    """
    Convierte coordenadas de tablero (fila, columna) a
    coordenadas de píxel de la esquina superior-izquierda
    de esa casilla.
    """
    x = MARGEN_IZQ + col * TAMANO_CASILLA
    y = MARGEN_SUP + fila * TAMANO_CASILLA
    return x, y


def pixel_a_fila_col(px, py):
    """
    Convierte coordenadas de píxel del mouse a coordenadas
    de tablero (fila, columna). Retorna None si el click
    está fuera del tablero.
    """
    # Verificar que el click esté dentro del área del tablero
    if (px < MARGEN_IZQ or px >= MARGEN_IZQ + ANCHO_TABLERO or
            py < MARGEN_SUP or py >= MARGEN_SUP + ALTO_TABLERO):
        return None

    col  = (px - MARGEN_IZQ) // TAMANO_CASILLA
    fila = (py - MARGEN_SUP) // TAMANO_CASILLA
    return int(fila), int(col)
